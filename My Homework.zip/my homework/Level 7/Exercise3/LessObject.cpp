//
//  LessObject.cpp
//  C++ Exercise
//
//  Created by 胡雨昕 on 2019/11/9.
//  Copyright © 2019 胡雨昕. All rights reserved.
//
// Source file for LessObject class.
//
#ifndef LessObject_cpp
#define LessObject_cpp

#include "LessObject.hpp"

template <typename T>
LessObject<T>::LessObject():limit(10.0){}

template <typename T>
LessObject<T>::LessObject(const T& t):limit(t){}

template <typename T>
LessObject<T>::LessObject(const LessObject<T>& source):limit(source.limit){}

//destructor
template <typename T>
LessObject<T>::~LessObject(){}
    
//member functions
template <typename T>
LessObject<T>& LessObject<T>::operator = (const LessObject<T>& source)
{
    if (this==&source){return *this;}
    limit=source.limit;
    return *this;
}

template <typename T>
int LessObject<T>::operator () (const T& t) const
{
    return t<limit;
}

#endif
