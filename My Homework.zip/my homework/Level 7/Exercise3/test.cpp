//
//  test.cpp
//  C++ Exercise
//
//  Created by 胡雨昕 on 2019/11/9.
//  Copyright © 2019 胡雨昕. All rights reserved.
//
//  Test the count_if algorithm, using global funtion and funtion object.

#include <iostream>
#include <vector>
#include "LessObject.cpp"
using namespace std;

//global function
int LessThanLimit(double input)
{
    double limit=10.0;
    return input<limit;
}

int main()

{
    vector<double> v;
    for (int i=0;i<20;i++)
    {
        v.push_back(i+0.5);
    }
    
    //using the global function
    double result1=count_if(v.begin(),v.end(),LessThanLimit);
    cout<<"The number of input smaller than 10 is "<<result1<<endl;
    
    //using the function object
    int limit=10.0;
    double result2=count_if(v.begin(),v.end(),LessObject<double>(limit));
    cout<<"The number of input smaller than 10 is "<<result2<<endl;
    
}
