//
//  LessObject.hpp
//  C++ Exercise
//
//  Created by 胡雨昕 on 2019/11/9.
//  Copyright © 2019 胡雨昕. All rights reserved.
//
// Source file for LessObject class.
//

#ifndef LessObject_hpp
#define LessObject_hpp

#include <stdio.h>
//constructors
template <typename T>
class LessObject
{
private:
    T limit;
public:
    //constructors
    LessObject();
    LessObject(const T& t);
    LessObject(const LessObject<T>& source);
    //destructors
    ~LessObject();
    
    //member functions
    LessObject& operator = (const LessObject<T>& source);
    int operator () (const T& t) const;
};

#endif /* LessObject_hpp */
