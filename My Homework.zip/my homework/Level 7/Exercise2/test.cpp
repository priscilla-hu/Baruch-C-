//
//  test.cpp
//  C++ Exercise
//
//  Created by 胡雨昕 on 2019/11/9.
//  Copyright © 2019 胡雨昕. All rights reserved.
//
//  create a function that calculates the sum of a container with doubles.

#include <iostream>
#include <list>
#include <vector>
#include <map>
using namespace std;

//calculates the sum of the complete container
template <typename T>
double Sum(const T& t)
{
    typename T::const_iterator it;
    double s=0;
    for (it=t.begin();it!=t.end();++it)
    {
        s+=*it;
    }
    return s;
}

//calculates the sum of elements in a map
template <typename T1,typename T2>
double Sum(const map<T1,T2>& t)
{
    typename map<T1,T2>::const_iterator it;
    double s=0;
    for (it=t.begin();it!=t.end();++it)
    {
        s+=it->second;
    }
    return s;
}


//calculates the sum between two iterators
template<typename T>
double Sum(const typename T::const_iterator& start, const typename T::const_iterator& end)
{
    double s=0;
    for (typename T::const_interator it=start;it<end;++it)
    {
        s+=*it;
    }
}

//calculates the sum between two iterators in map

template <typename T1,typename T2>
double Sum(const typename map<T1,T2>::const_interator& start,const typename map<T1,T2>::const_interator& end)
{
    typename map<T1,T2>::const_iterator it;
    double s=0;
    for (it=start;it!=end;++it)
    {
        s+=it->second;
    }
    return s;
}


int main()
{
    //Create a list of doubles and add some data.
    list<double> l;
    for (int i=0;i<10;i++)
    {
        l.push_back(i+0.5);
    }
    
    cout<<"The sum of elements in the list is: "<<Sum(l)<<endl;
    
    
    
    //Create a vector of doubles and add some data.
    vector<double> v;
    v.reserve(10);
    for (int i=0;i<10;i++)
    {
        v.push_back(i+0.5);
    }
    v[2]=3.1;
    v[3]=4.1;
    
    cout<<"The sum of elements in the vector is: "<<Sum(v)<<endl;
    

    
    //Create a map that maps strings to doubles.
    map<string,double> m;
    string str[4]={"a","b","c","d"};
    for (int i=0; i<4 ;i++)
    {
        m[str[i]]=i+0.1;
    }
    
    cout<<"The sum of elements in the map is: "<<Sum(m)<<endl;
    
}
