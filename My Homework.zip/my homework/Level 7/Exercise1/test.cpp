//
//  test.cpp
//  C++ Exercise
//
//  Created by 胡雨昕 on 2019/11/9.
//  Copyright © 2019 胡雨昕. All rights reserved.
//
//  practice with the different STL containers.

#include <iostream>
#include <list>
#include <vector>
#include <map>
using namespace std;

int main()
{
    //Create a list of doubles and add some data.
    list<double> l;
    for (int i=0;i<10;i++)
    {
        l.push_back(i+0.5);
    }

    //Use the front() and back() functions to access the first and last element.
    cout<<"first element:"<<l.front()<<endl;
    cout<<"last element:"<<l.back()<<endl;
    
    //Create a vector of doubles and add some data.
    vector<double> v;
    v.reserve(10);
    for (int i=0;i<10;i++)
    {
        v.push_back(i+0.5);
    }
    
    //Then use the index operator to access some elements. Also make the vector grow.
    v[2]=3.1;
    v[3]=4.1;
    for (int i=0;i<4;i++)
    {
        cout<<v[i]<<",";
    }
    cout<<endl;
    
    //Create a map that maps strings to doubles.
    map<string,double> m;
    string str[4]={"a","b","c","d"};

    //Fill the map and access elements using the square bracket operator.
    for (int i=0; i<4 ;i++)
    {
        m[str[i]]=i+0.1;
    }
    for (int i=0; i<m.size();i++)
    {
        cout<<m[str[i]]<<",";
    }
    cout<<endl;
    
}
