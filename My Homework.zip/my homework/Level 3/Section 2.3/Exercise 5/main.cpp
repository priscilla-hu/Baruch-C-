//
//  main.cpp
//  C++ Exercise
//
//  Created by 胡雨昕 on 2019/9/11.
//  Copyright © 2019 胡雨昕. All rights reserved.
//

#include <iostream>
#include "Line.hpp"

int main()
{

    Point p1(2,2),p2(3,3);
    Line l(p1,p2);
    cout<< l.Length() <<endl;
    cout<< l.ToString()<<endl;
    
    
}
