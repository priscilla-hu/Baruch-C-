//
//  Line.cpp
//  C++ Exercise
//
//  Created by 胡雨昕 on 2019/9/11.
//  Copyright © 2019 胡雨昕. All rights reserved.
//

#include "Line.hpp"
#include <iostream>
#include <sstream>

Line::Line():P1(0,0),P2(0,0)
{
    
}

Line::Line(Point& new_P1, Point& new_P2):P1(new_P1),P2(new_P2)
{
    
}

Line::Line(const Line& ln)
{
    
}

Line::~Line()
{
    
}

Point Line::start() const
{
    return P1;
}

Point Line::end() const
{
    return P2;
}

void Line::start(Point& P1_new)
{
    P1=P1_new;
}

void Line::end(Point& P2_new)
{
    P2=P2_new;
}

double Line::Length() const
{
    return P1.Distance(P2);
}

string Line::ToString() const
{
    return "the Line starts with "+P1.ToString()+" and ends with "+P2.ToString();
}
