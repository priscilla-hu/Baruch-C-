//
//  main.cpp
//  C++ Exercise
//
// rename the DistanceOrigin() function to Distance()
// rename the SetX() andGetX() functions to just X()

#include <iostream>
#include "Point.hpp" //input headerfile
using namespace std;

int main()
{
    double x,y;
    string str_x,str_y;
    
    cout<<"enter x- and y-coordinates:";
    cin>>x>>y; //ask user for x,y
    
    Point pt1; //create a Point object
    
    pt1.X(x); //set the coordinates
    pt1.Y(y);
    
    Point p2(1,1);
    
    cout<<pt1.ToString()<<std::endl;
    cout<<"The distance between this point and (1,1) is "<<pt1.Distance(p2)<<endl;
 
    const Point cp(1.5,3.9);
    cout<<cp.X()<<endl;
    //cp.X(0.3);  //complie error
    
    return 0;
}
