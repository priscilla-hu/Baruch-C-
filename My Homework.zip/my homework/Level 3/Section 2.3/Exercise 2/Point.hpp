//
//  Point.hpp
//  a Point class with x- and y-coordinates
//

#ifndef Point_hpp
#define Point_hpp

#include <iostream>

class Point
{
private:
    double x;
    double y;
    
public:
    //constructors & destructors
    Point();
    Point(double x,double y); // Initialize with x and y value
    ~Point();
    
    //copy constructor
    Point(const Point& pt);
    
    //accessing functions
    double GetX() const;
    double GetY() const;
    
    //modifiers
    void SetX(double x_new);// const;
    void SetY(double y_new);
    
    std::string ToString();
    
    double DistanceOrigin();
    double Distance(const Point& p);
    
    
};


#endif /* Point_hpp */
