//
//  main.cpp
//  C++ Exercise
//
// Without constructor, constructor is called twice and destructor is called three times.
// After adding the copy constructor, both constructor and destructor are called three times.
// Copy constructor is called automatically, when the function pt1.Distance(p2) is called

#include <iostream>
#include "Point.hpp" //input headerfile
using namespace std;

int main()
{
    double x,y;
    string str_x,str_y;
    
    cout<<"enter x- and y-coordinates:";
    cin>>x>>y; //ask user for x,y
    
    Point pt1(x,y); //create a Point object
    
    //pt1.SetX(x); //set the coordinates
    //pt1.SetY(y);
    
    Point p2(1,1);
    
    cout<<pt1.ToString()<<std::endl;
    cout<<"The distance between this point and (1,1) is "<<pt1.Distance(p2)<<endl;
    
    return 0;
}
