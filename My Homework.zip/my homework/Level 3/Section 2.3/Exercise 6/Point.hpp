//
//  Point.hpp
//
// rename the DistanceOrigin() function to Distance()
// rename the SetX() andGetX() functions to just X()
//

#ifndef Point_hpp
#define Point_hpp

#include <iostream>

class Point
{
private:
    double x;
    double y;
    
public:
    //constructors & destructors
    Point();
    Point(double x,double y); // Initialize with x and y value, 这里的x,y与class里面的x,y是同一个东西？
    ~Point();
    
    //copy constructor
    Point(const Point& pt);
    
    //accessing functions
    double X() const;
    double Y() const;
    
    //modifiers
    void X(double x_new);// const;
    void Y(double y_new);
    
    std::string ToString() const;
    
    double Distance() const;
    double Distance(const Point& p) const;
    
    
};


#endif /* Point_hpp */
