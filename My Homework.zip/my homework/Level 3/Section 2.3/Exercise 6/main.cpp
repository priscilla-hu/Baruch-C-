//
//  main.cpp
//  C++ Exercise
//
//  Created by 胡雨昕 on 2019/9/11.
//  Copyright © 2019 胡雨昕. All rights reserved.
//

#include <iostream>
#include "Circle.hpp"

int main()
{
    Point pt;
    double r=1;
    Circle cl(pt,r);
    cout<< cl.Diameter()<<endl;
    cout<< cl.Area()<<endl;
    cout<< cl.Circumference()<<endl;
    cout<< cl.ToString()<<endl;
}
