//
//  Point.cpp
//
// rename the DistanceOrigin() function to Distance()
// rename the SetX() andGetX() functions to just X()
//
#include <iostream>
#include <sstream>
#include <cmath>
#include "Point.hpp"
using namespace std;


Point::Point() : x(0), y(0)
{
    cout<<"constructor is called!"<<endl;
}

Point::Point(double newx, double newy) : x(newx), y(newy)
{
    cout<<"constructor is called!"<<endl;
}

Point::Point(const Point& pt)
{
    cout<<"copy constructor is called!"<<endl;
    x=pt.x;
    y=pt.y;
}

Point::~Point()
{// Desconstructor
    cout<<"destructor is called!"<<endl;
}


//selectors

//access the x value

double Point::X() const
{
    return x;
}

//access the y value
double Point::Y() const
{
    return y;
}

//modifiers

//set the x value
void Point::X(double x_new)// const
{
    x=x_new;
    return;
}

//set the y value
void Point::Y(double y_new)
{
    y=y_new;
    return;
}

//to string
string Point::ToString()
{
    stringstream stream_x,stream_y;
    string result_x,result_y;
    
    stream_x << Point::X();
    stream_x >> result_x;
    stream_y << Point::X();
    stream_y >> result_y;
    
    return "Point("+result_x+","+result_y+")";
}

//distance
double Point::Distance()
{
    double x_d,y_d;
    x_d=Point::X();
    y_d=Point::Y();
    return sqrt(x_d*x_d+y_d*y_d);
}

double Point::Distance(const Point& p)
{
    double x_d,y_d;
    double x_p,y_p;

    x_d=Point::X();
    y_d=Point::Y();
    x_p=p.X(); // function GetX() should be a constant function in order to be called by a constant object.
    y_p=p.Y();
    
    //test if you can change the input point.
    
    //Got compile error:
    //'this' argument to member function 'SetX' has type 'const Point', but function is not marked const
    //After add const to the function SetX(), get another compile error:
    //Cannot assign to non-static data member within const member function 'SetX'
    
    //p.SetX(3);
    
    return sqrt(pow(x_d-x_p,2)+pow(y_d-y_p,2));
}

