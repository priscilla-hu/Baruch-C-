//
//  Point.cpp
//  a Point class with x- and y-coordinates
//
#include <iostream>
#include <sstream>
#include "Point.hpp"
using namespace std;

//selectors

//access the x value
Point::Point() : x(0), y(0)
{
    
}

Point::Point(double newx, double newy) : x(newx), y(newy)
{
    
}

Point::~Point()
{// Desconstructor

}

double Point::GetX()
{
    return x;
}

//access the y value
double Point::GetY()
{
    return y;
}

//modifiers

//set the x value
void Point::SetX(double x_new)
{
    x=x_new;
    return;
}

//set the y value
void Point::SetY(double y_new)
{
    y=y_new;
    return;
}

//to string
string Point::ToString()
{
    stringstream stream_x,stream_y;
    string result_x,result_y;
    
    x=Point::GetX();
    y=Point::GetY();
    
    stream_x << x;
    stream_x >> result_x;
    stream_y << y;
    stream_y >> result_y;
    
    return "Point("+result_x+","+result_y+")";
}

