//
//  main.cpp
//  C++ Exercise
//
//  Created by 胡雨昕 on 2019/9/7.
//  Copyright © 2019 胡雨昕. All rights reserved.
//

#include <iostream>
#include "Point.hpp" //input headerfile

int main()
{
    double x,y;
    std::string str_x,str_y;
    
    std::cout<<"enter x- and y-coordinates:";
    std::cin>>x>>y; //ask user for x,y
    
    Point pt; //create a Point object
    
    pt.SetX(x); //set the coordinates
    pt.SetY(y);
    
    std::cout<<pt.ToString()<<std::endl;
}
