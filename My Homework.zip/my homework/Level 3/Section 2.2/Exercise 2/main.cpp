//
//  main.cpp
//  C++ Exercise
//
//  Created by 胡雨昕 on 2019/9/7.
//  Copyright © 2019 胡雨昕. All rights reserved.
//

#include <iostream>
#include "Point.hpp" //input headerfile
using namespace std;

int main()
{
    double x,y;
    string str_x,str_y;
    
    cout<<"enter x- and y-coordinates:";
    cin>>x>>y; //ask user for x,y
    
    Point pt; //create a Point object
    
    pt.SetX(x); //set the coordinates
    pt.SetY(y);
    
    Point p2(1,1);
    
    cout<<pt.ToString()<<std::endl;
    cout<<"The distance between this point and (1,1) is "<<pt.Distance(p2)<<endl;
    
    return 0;
}
