//
//  Point.hpp
//  a Point class with x- and y-coordinates
//

#ifndef Point_hpp
#define Point_hpp

#include <iostream>

class Point
{
private:
    double x;
    double y;
    
public:
    //constructors & destructors
    Point();
    Point(double x,double y); // Initialize with x and y value
    ~Point();
    
    //accessing functions
    double GetX();
    double GetY();
    
    //modifiers
    void SetX(double x_new);
    void SetY(double y_new);
    
    std::string ToString();
    
    double DistanceOrigin();
    double Distance(Point p);
    
    
};


#endif /* Point_hpp */
