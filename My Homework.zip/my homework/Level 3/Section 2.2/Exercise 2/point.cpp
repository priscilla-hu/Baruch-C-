//
//  Point.cpp
//  a Point class with x- and y-coordinates
//
#include <iostream>
#include <sstream>
#include <cmath>
#include "Point.hpp"
using namespace std;


Point::Point() : x(0), y(0)
{
    
}

Point::Point(double newx, double newy) : x(newx), y(newy)
{
    
}

Point::~Point()
{// Desconstructor
    
}


//selectors

//access the x value

double Point::GetX()
{
    return x;
}

//access the y value
double Point::GetY()
{
    return y;
}

//modifiers

//set the x value
void Point::SetX(double x_new)
{
    x=x_new;
    return;
}

//set the y value
void Point::SetY(double y_new)
{
    y=y_new;
    return;
}

//to string
string Point::ToString()
{
    stringstream stream_x,stream_y;
    string result_x,result_y;
    
    x=Point::GetX();
    y=Point::GetY();
    
    stream_x << x;
    stream_x >> result_x;
    stream_y << y;
    stream_y >> result_y;
    
    return "Point("+result_x+","+result_y+")";
}

//distance
double Point::DistanceOrigin()
{
    x=Point::GetX();
    y=Point::GetY();
    return sqrt(x*x+y*y);
}

double Point::Distance(Point p)
{
    double x_p,y_p;
    x=Point::GetX(); //do not have to declare x,y here, already declared in the hpp file
    y=Point::GetY();
    x_p=p.GetX();
    y_p=p.GetY();
    return sqrt(pow(x-x_p,2)+pow(y-y_p,2));
}
