//
//  test.cpp
//  C++ Exercise
//
//  Created by 胡雨昕 on 2019/11/3.
//  Copyright © 2019 胡雨昕. All rights reserved.
//

#include "Stack.cpp"
#include "StackException.hpp"
#include <iostream>
using namespace std;

int main()
{
    // st0,st1,st2 all include a data member array of size 10
    
    // Test defalut constructor.
    Stack<int,5> st0;
    
    // Test copy constructor.
    Stack<int,5> st1(st0);
    
    // Test assignment operator.
    Stack<int,5> st2 = st0;

    // Test Push()
    for (int i = 0; i < 6; i++)
    {
        try{
            st0.Push(i);
        }
        catch (StackException& ex){
            cout << ex.GetMessage() << endl;
        }
    }
    
    // Test Pop().
    for (int i = 0; i < 6; i++)
    {
        try{
            cout << st0.Pop() << endl;
        }
        catch (StackException& ex){
            cout << ex.GetMessage() << endl;
        }
        
        try{
            cout << st1.Pop() << endl;
        }
        catch (StackException& ex){
            cout << ex.GetMessage() << endl;
        }
    }
}
