//
//  StackException.hpp
//  C++ Exercise
//
//  Created by 胡雨昕 on 2019/11/4.
//  Copyright © 2019 胡雨昕. All rights reserved.
//

#ifndef StackException_hpp
#define StackException_hpp
#include <iostream>

class StackException
{
public:
    virtual std::string GetMessage() const=0;
};

class StackFullException: public StackException
{
    std::string GetMessage() const
    {
        return "Stack full exception";
    }
};

class StackEmptyException: public StackException
{
    std::string GetMessage() const
    {
        return "Stack empty exception";
    }
};

#endif /* StackException_hpp */
