//
//  Stack.hpp
//  C++ Exercise
//
//  Created by 胡雨昕 on 2019/11/4.
//  Copyright © 2019 胡雨昕. All rights reserved.
//
// Change the Stack class so that it uses a value template argument to set the stack size

#ifndef Stack_hpp
#define Stack_hpp

#include <iostream>
#include "Array.hpp"

template <typename T,int size>
class Stack
{
private:
    Array<T> m_Array;
    int m_current;
public:
    //cosntructors
    Stack();
    //Stack(int size); cannot change the size
    Stack(const Stack<T,size>& st);
    //only stacks with the same size template argument can be copied/assigned.
    
    //destructor
    ~Stack();
    
    //assignment operator
    Stack<T,size>& operator = (const Stack<T,size>& st);
    //only stacks with the same size template argument can be copied/assigned.
    
    //functions
    void Push(T type);
    T& Pop();
};

#ifndef Stack_cpp
#include "Stack.cpp"
#endif

#endif /* Stack_hpp */
