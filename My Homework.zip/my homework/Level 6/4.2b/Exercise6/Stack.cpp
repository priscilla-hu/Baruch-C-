//
//  Stack.cpp
//  C++ Exercise
//
//  Created by 胡雨昕 on 2019/11/4.
//  Copyright © 2019 胡雨昕. All rights reserved.
//

#ifndef Stack_cpp
#define Stack_cpp

#include "Stack.hpp"
#include "Array.hpp"
#include "StackException.hpp"

template <typename T,int size>
Stack<T,size>::Stack():m_current(0),m_Array(size) //use the default constructor of Array<T> in this case
{//default constructor
}

template <typename T,int size>
Stack<T,size>::Stack(const Stack<T,size>& st):m_current(st.m_current),m_Array(st.m_Array)
{//copy constructor
}

template <typename T,int size>
Stack<T,size>::~Stack()
{//destructor
}

template <typename T,int size>
Stack<T,size>& Stack<T,size>::operator = (const Stack<T,size>& st)
{
    if (&st==this)
    {
        return *this;
    }
    m_current=st.m_current;
    m_Array=st.m_array;
    
    return *this;
}

template <typename T,int size>
T& Stack<T,size>::Pop()
{
    try{
        m_current--;
        return(m_Array[m_current]);
    }
    catch(ArrayException& ex){
        throw StackEmptyException();
        m_current = 0;
    }
}

template <typename T,int size>
void Stack<T,size>::Push(T newT)
{
    try{
        m_Array[m_current]=newT;
        m_current++;
    }
    catch(ArrayException& ex){
        throw StackFullException();
    }
}

#endif
