//
//  test.cpp
//  C++ Exercise
//
//  Created by 胡雨昕 on 2019/11/3.
//  Copyright © 2019 胡雨昕. All rights reserved.
//

#include <iostream>
#include "Array.hpp"
using namespace std;

int main()
{
    Array<int> intArray1;
    Array<int> intArray2;
    Array<double> doubleArray;
    
    cout<<intArray1.DefaultSize()<<endl;//10
    cout<<intArray2.DefaultSize()<<endl;//10
    cout<<doubleArray.DefaultSize()<<endl;//10
    
    intArray1.DefaultSize(15);
    cout<<intArray1.DefaultSize()<<endl;//15
    cout<<intArray2.DefaultSize()<<endl;//15
    //static member data is independent of the specific object of class Array<int>
    //when m_static_size is changed, the default size has been changed for all objects of class Array<int>
    cout<<doubleArray.DefaultSize()<<endl;//10
    //doubleArray is an instance of class Array<double> instead of Array<int>
    //Hence, when the default size of intArray1 is changed, the default size of doubleArray will not be affected.
}


