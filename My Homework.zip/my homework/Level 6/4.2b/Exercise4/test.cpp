//
//  test.cpp
//  C++ Exercise
//
//  Created by 胡雨昕 on 2019/11/3.
//  Copyright © 2019 胡雨昕. All rights reserved.
//

#include "Stack.cpp"
#include <iostream>
using namespace std;

int main()
{
    // st0,st1,st2 all include a data member array of size 10
    
    // Test defalut constructor.
    Stack<int> st0;
    
    // Test copy constructor.
    Stack<int> st1(st0);
    
    // Test assignment operator.
    Stack<int> st2 = st0;

    // Test Push()
    for (int i = 0; i < 11; i++)
    {
        try
        {
            st0.Push(i); //the data member Array would be like (0,1,2,3,4,5,6,7,8,9)
        }
        catch (ArrayException& ex)
        {
            cout << ex.GetMessage() << endl;
        }
    }//the current index for st0 and st1 are 9 and 0.
    
    // Test Pop().
    for (int i = 0; i < 11; i++)
    {
        try
        {
            cout << st0.Pop() << endl;
        }
        catch (ArrayException& ex)
        {
            cout << ex.GetMessage() << endl;
        }
        
        try
        {
            cout << st1.Pop() << endl;
        }
        catch (ArrayException& ex)
        {
            cout << ex.GetMessage() << endl;
        }
    }
}
