//
//  Stack.cpp
//  C++ Exercise
//
//  Created by 胡雨昕 on 2019/11/4.
//  Copyright © 2019 胡雨昕. All rights reserved.
//

#ifndef Stack_cpp
#define Stack_cpp

#include "Stack.hpp"
#include "Array.hpp"

template <typename T>
Stack<T>::Stack():m_current(0) //use the default constructor of Array<T> in this case
{//default constructor
}

template <typename T>
Stack<T>::Stack(int size):m_current(0),m_Array(size){}

template <typename T>
Stack<T>::Stack(const Stack<T>& st):m_current(st.m_current),m_Array(st.m_Array)
{//copy constructor
}

template <typename T>
Stack<T>::~Stack()
{//destructor
}

template <typename T>
Stack<T>& Stack<T>::operator = (const Stack<T>& st)
{
    if (&st==this)
    {
        return *this;
    }
    m_current=st.m_current;
    m_Array=st.m_array;
    
    return *this;
}

template <typename T>
T& Stack<T>::Pop()
{
    if (m_current<1)
    {
        return(m_Array[m_current-1]);
    }
    else
    {
        m_current--;
        return(m_Array[m_current]);
    }
}

template <typename T>
void Stack<T>::Push(T newT)
{
    m_Array[m_current]=newT;
    m_current++;
}

#endif
