//
//  ArrayException.cpp
//  C++ Exercise
//
//  Created by 胡雨昕 on 2019/11/3.
//  Copyright © 2019 胡雨昕. All rights reserved.
//

#include "ArrayException.hpp"
#include <sstream>

using namespace std;

OutOfBoundException::OutOfBoundException(int i){index=i;}
OutOfBoundException::~OutOfBoundException(){}
std::string OutOfBoundException::GetMessage() const
{
    stringstream stream;
    
    stream << "Index " << index << " is out of bound.";
    
    return stream.str();
}

//cosntructor
IncompatibleSizeException::IncompatibleSizeException(){}

//destructor
IncompatibleSizeException::~IncompatibleSizeException(){}

std::string IncompatibleSizeException::GetMessage() const
{
    return "Incompatible size of arrays.";
}
