//
//  Stack.hpp
//  C++ Exercise
//
//  Created by 胡雨昕 on 2019/11/4.
//  Copyright © 2019 胡雨昕. All rights reserved.
//

#ifndef Stack_hpp
#define Stack_hpp

#include <iostream>
#include "Array.hpp"

template <typename T>
class Stack
{
private:
    Array<T> m_Array;
    int m_current;
public:
    //cosntructors
    Stack();
    Stack(int curr);
    Stack(const Stack<T>& st);
    
    //destructor
    ~Stack();
    
    //assignment operator
    Stack<T>& operator = (const Stack<T>& st);
    
    //functions
    void Push(T type);
    T& Pop();
};

#ifndef Stack_cpp
#include "Stack.cpp"
#endif

#endif /* Stack_hpp */
