//
//  PointArray.cpp
//  C++ Exercise
//
//  Created by 胡雨昕 on 2019/11/3.
//  Copyright © 2019 胡雨昕. All rights reserved.
//


#include "PointArray.hpp"
//constructors

PointArray::PointArray():Array<Point>()
{//default constructor
}

PointArray::PointArray(int size):Array<Point>(size){}

PointArray::PointArray(const PointArray& pa):Array<Point>(pa)
{//copy constructor
}

PointArray::~PointArray()
{//destructor
}

//assignment operator
PointArray PointArray::operator = (const PointArray& pa)
{
    if (&pa==this){return *this;}
    Array<Point>::operator = (pa);
    return *this;
}

//function
double PointArray::Length() const
{
    int n=(*this).Size();
    double length=0;
    for (int i=0;i!=n-1;i++)
    {
        Point p0=(*this).GetElement(i);
        Point p1=(*this).GetElement(i+1);
        length+=p0.Distance(p1);
    }
    return length;
}

