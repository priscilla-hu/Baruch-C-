//
//  test.cpp
//  C++ Exercise
//
//  Created by 胡雨昕 on 2019/11/3.
//  Copyright © 2019 胡雨昕. All rights reserved.
//

#include <iostream>
#include "Array.hpp"
#include "ArrayException.hpp"
#include "PointArray.hpp"
#include "Point.hpp"

using namespace std;

int main()
{
    // Test constructors.
    PointArray pa0;
    cout << "PointArray0: " << endl << "size = " << pa0.Size() << endl;
    
    PointArray pa1(10);
    cout << "PointArray1: " << endl;
    for (int i = 0; i < pa1.Size(); i++)
    {
        pa1[i] = Point(i, 2*i);
        cout << pa1[i] << endl;
    }
    
    //Test the copy constructor
    PointArray pa2(pa1);
    cout << "PointArray2: " << endl;
    for (int i = 0; i < pa2.Size(); i++)
    {
        cout << pa2[i] << endl;
    }
    
    // Test assignment operator.
    PointArray pa3 = pa1;
    cout << "PointArray3: " << endl;
    for (int i = 0; i < pa3.Size(); i++)
    {
        cout << pa3[i] << endl;
    }
    
    // Test Length() function.
    cout << "Length of PointArray1 = " << pa1.Length() << endl;

}
