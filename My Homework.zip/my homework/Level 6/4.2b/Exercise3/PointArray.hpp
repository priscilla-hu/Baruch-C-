//
//  PointArray.hpp
//  C++ Exercise
//
//  Created by 胡雨昕 on 2019/11/3.
//  Copyright © 2019 胡雨昕. All rights reserved.
//

#ifndef PointArray_hpp
#define PointArray_hpp

#include "Array.hpp"
#include "Point.hpp"

class PointArray: public Array<Point>
{
public:
    //constructors
    PointArray();//default constructor
    PointArray(int size);
    PointArray(const PointArray& pa);//copy constructor
    
    //destructor
    ~PointArray();
    
    //assignment operator
    PointArray operator = (const PointArray& pa);
    
    //function
    double Length() const;
};

#endif /* PointArray_hpp */
