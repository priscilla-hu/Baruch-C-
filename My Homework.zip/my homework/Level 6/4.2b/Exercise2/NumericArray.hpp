//
//  NumericArray.hpp
//  C++ Exercise
//
//  Created by 胡雨昕 on 2019/11/3.
//  Copyright © 2019 胡雨昕. All rights reserved.
//

#ifndef NumericArray_hpp
#define NumericArray_hpp

#include <iostream>
#include "Array.hpp"

template <typename T>
class NumericArray:public Array<T>
{
public:
    //constructors
    NumericArray();//default constructor
    NumericArray(int size);
    NumericArray(const NumericArray<T>& narray);//copy constructor
    
    //destructor
    ~NumericArray();
    
    //operators
    NumericArray& operator = (const NumericArray& na);//assignment operator
    NumericArray operator * (double b);
    NumericArray operator + (const NumericArray& na);
    
    //functions
    int DotProduct(const NumericArray& na);
};

#ifndef NumericalArray_CPP
#include "NumericArray.cpp"
#endif

#endif /* NumericArray_hpp */
