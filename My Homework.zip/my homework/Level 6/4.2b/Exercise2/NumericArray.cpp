//
//  NumericArray.cpp
//  C++ Exercise
//
//  Created by 胡雨昕 on 2019/11/3.
//  Copyright © 2019 胡雨昕. All rights reserved.
//
#ifndef NumericalArray_CPP
#define NumericalArray_CPP

#include "ArrayException.hpp"
#include "NumericArray.hpp"

template <typename T>
NumericArray<T>::NumericArray():Array<T>()
{//default constructor
}

template <typename T>
NumericArray<T>::NumericArray(int size):Array<T>(size){}

template <typename T>
NumericArray<T>::NumericArray(const NumericArray<T>& narray):Array<T>(narray)
{//copy constructor
}

template <typename T>
NumericArray<T>::~NumericArray()
{//destructor
}

template <typename T>
NumericArray<T>& NumericArray<T>::operator = (const NumericArray& na)
{//assignment operator
    //check if they are same objects
    if (&na==this){return *this;}
    //call the base class assignment
    Array<T>::operator = (na);
    return *this;
}

template <typename T>
NumericArray<T> NumericArray<T>::operator * (double b)
{
    NumericArray<T> na=NumericArray(*this);
    for (int i=0;i!=na.Size();i++)
    {
        na[i]=na[i]*b;
    }
    return na;
}

template <typename T>
NumericArray<T> NumericArray<T>::operator + (const NumericArray& na)
{
    if (na.Size()!=(*this).Size())
    {
        throw(IncompatibleSizeException());
    }
    NumericArray<T> temp_na(na);
    for (int i=0;i!=na.Size();i++)
    {
        temp_na[i]=na[i]+(*this)[i];
    }
    return temp_na;
}

//functions
template <typename T>
int NumericArray<T>::DotProduct(const NumericArray& na)
{
    if (na.Size()!=(*this).Size())
    {
        throw IncompatibleSizeException();
    }
    T result(0);
    for (int i=0;i!=na.Size();i++)
    {
        result+=na[i]*(*this)[i];
    }
    return result;
}
#endif
