//
//  test.cpp
//  C++ Exercise
//
//  Created by 胡雨昕 on 2019/11/3.
//  Copyright © 2019 胡雨昕. All rights reserved.
//

#include <iostream>
#include "Array.hpp"
#include "ArrayException.hpp"
#include "NumericArray.hpp"
using namespace std;

int main()
{
    //default constructor
    NumericArray<int> arr1;
    cout<<"size="<<arr1.Size()<<endl;
    
    //constructor with size as input
    NumericArray<int> arr2(2);
    arr2[0]=0;
    arr2[1]=1;
    cout<<"NumericArray2: " << endl << arr2[0] << "," << arr2[1] << endl;
    
    //copy constructor
    NumericArray<int> arr3(arr2);
    cout << "NumericArray3: " << endl << arr3[0] << "," << arr3[1] << endl;
    
    //assignment operator
    NumericArray<int> arr4 = arr1;
    cout << "NumericArray4: " << endl;
    for (int i = 0; i < arr4.Size(); i++)
    {
        cout << arr4[i] << endl;
    }
    
    // * operator
    NumericArray<int> arr5 = arr2 * 3;
    cout << "NumericArray5: " << endl;
    for (int i = 0; i < arr5.Size(); i++)
    {
        cout << arr5[i] << endl;
    }
    
    // + operator
    NumericArray<int> arr6 = arr2 +arr5;
    cout<<arr6[0]<<arr6[1]<<endl;
    
    // dot product
    int dp1;
    cout<<"dot product1:"<<endl;
    dp1=arr1.DotProduct(arr1*3);
    cout<<dp1<<endl;
    
    //test the error handle
    int dp2;
    cout<<"dot product2:"<<endl;
    try
    {
        dp2=arr1.DotProduct(arr2);
    }
    catch (ArrayException& ex)
    {
        cout<<ex.GetMessage()<<endl;
    }
    
    //What assumptions do you make about the type used as template argument? Can you create a numeric array with Point objects?
    // assumptions on template argument: support numeric operations, including +, * and dot product.
    // Although we can create a numeric array with Point objects,
    // we cannot perform the above operations because the Point class does not have them.
    return 0;
}
