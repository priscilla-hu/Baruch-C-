//
//  Point.hpp
//  C++ Exercise
//
//  Created by 胡雨昕 on 2019/11/3.
//  Copyright © 2019 胡雨昕. All rights reserved.
//

#ifndef Point_hpp
#define Point_hpp

#include <iostream>
using namespace std;
class Point
{
private:
    double x;
    double y;
public:
    Point();//constructor
    Point(double x, double y);
    Point(const Point& pt);//copy constructor
    ~Point();//destructor
    
    //operators
    Point operator - () const; // Negate the coordinates.
    Point operator * (double factor) const; // Scale the coordinates.
    Point operator + (const Point& p) const; // Add coordinates.
    bool operator == (const Point& p) const; // Equally compare operator.
    Point& operator = (const Point& source); // Assignment operator.
    Point& operator *= (double factor); // Scale the coordinates & assign
    
    //accessing functions
    double X() const;
    double Y() const;
    
    //modifiers
    void X(double x_new);
    void Y(double y_new);
    
    // Global operator overloading
    friend ostream& operator << (ostream& os, const Point& p); // Send to ostream
    
    std::string ToString() const;
    
    double Distance() const;
    double Distance(const Point&p) const;
};

#endif /* Point_hpp */
