//
//  Array.cpp
//  C++ Exercise
//
//  Created by 胡雨昕 on 2019/11/3.
//  Copyright © 2019 胡雨昕. All rights reserved.
//

#ifndef Array_cpp // Must be the same name as in source file
#define Array_cpp

#include "Array.hpp"
#include "ArrayException.hpp"
#include <iostream>
#include <sstream>
using namespace std;

template <typename T>
Array<T>::Array():m_size(10),m_data(new T[10])
{//defualt constructor (you need to be specific about the m_size here.)
}

template <typename T>
Array<T>::Array(int s):m_size(s),m_data(new T[m_size]){}

template <typename T>
Array<T>::Array(const Array& source)
{//copy constructor
    m_size=source.m_size;
    m_data=new T[source.m_size];
    for (int i=0;i<source.m_size;i++)
        m_data[i]=source.m_data[i];
}

template <typename T>
Array<T>::~Array()
{//destructor
    delete [] m_data;
}

template <typename T>
Array<T> Array<T>::operator = (const Array& source)
{//assignment operator
    if (&source!=this)
    {
        delete [] m_data; //first delete the memory
        
        m_size=source.m_size;
        m_data=new T[source.m_size];
        
        for (int i=0;i<source.m_size;i++)
            m_data[i]=source.m_data[i];
    }
    return *this;
}

template <typename T>
int Array<T>::Size() const
{
    return m_size;
}

template <typename T>
void Array<T>::SetElement(int index, T newT)
{
    if (index>=m_size || index<0)
    {
        throw(OutOfBoundException(index));
    }
    
    m_data[index]=newT;
}

template <typename T>
T Array<T>::GetElement(int index) const
{
    if (index>=m_size || index<0)
    {
        throw(OutOfBoundException(index));
    }
    
    return m_data[index];
}

template <typename T>
T& Array<T>::operator [] (int index)
{
    if (index < 0 || index >= m_size)
    {
        throw(OutOfBoundException(index));
    }
    
    return m_data[index];
}

template <typename T>
const T& Array<T>::operator [] (int index) const
{
    if (index>=m_size || index<0)
    {
        throw(OutOfBoundException(index));
    }
    
    return m_data[index];
}

#endif
