//
//  test.cpp
//  C++ Exercise
//
//  Created by 胡雨昕 on 2019/11/3.
//  Copyright © 2019 胡雨昕. All rights reserved.
//

#include <iostream>
#include "Array.hpp"
#include "Point.hpp"
using namespace std;

int main()
{
    int size=4;
    
    // Create two arrays of points.
    Array<Point> points1(size);
    
    // Test [] operator for writing.
    points1[0] = Point(0, 0);
    points1[1] = Point(1, 1);
    points1[2] = Point(2, 2);
    points1[3] = Point(3, 3);

    // Test GetElement().
    cout<<points1.GetElement(0)<<endl;//(0,0)

    // Test SetElement().
    Point pt(1,1);
    points1.SetElement(0,pt);
    cout<<points1.GetElement(0)<<endl;//(1,1)

    // Using copy constructor.
    Array<Point> points2(points1);
    
    // Test [] operator for const Array object.
    const Array<Point> points3(points1);
    cout<<points3[3]<<endl;//(3,3)

    // Test assignment operator and [] operator for reading.
    cout<<points1[3]<<endl;//(3,3)

}
