
//
//  Exercise 1.cpp
//  C++ Exercise
//
//  Created by 胡雨昕 on 2019/8/29.
//  Copyright © 2019 胡雨昕. All rights reserved.
//

#include <stdio.h>

int main()
{

    while(true)
    {
        char string[1024];
        int t=0;
        char c;
        while((c=getchar()) !=1&&c!='\n')
        {
            string[t++]=c;
        }
        if (c==1)
        {
            printf("CTRL + A is a correct ending.\n");
            break;
        }
        if (c=='\n')
        {
            string[t]=0;
            printf("%s\n",string);
        }
    }
    return 0;
}
