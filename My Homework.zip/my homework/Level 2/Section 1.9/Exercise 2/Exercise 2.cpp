//
//  Exercise 2.cpp
//  C++ Exercise
//
//  Created by 胡雨昕 on 2019/8/29.
//  Copyright © 2019 胡雨昕. All rights reserved.
//

#include <stdio.h>
#include <stdlib.h>
#include <cstdio>


int main()
{
    //char str[80];
    //printf("pick a file!");
    FILE * fp;
    fp = fopen("file.txt", "w+"); //open a file

    while(true)
    {
        char string[1024];
        int t=0;
        char c;
        while((c=getchar()) !=1&&c!='\n') // get the string
        {
            string[t++]=c;
        }
        if (c==1)
        {
            fprintf(fp,"CTRL + A is a correct ending.\n");
            break;
        }
        if (c=='\n')
        {
            string[t]=0;
            fprintf(fp,"%s\n",string); //print to the file
        }
    }
    fclose(fp);
    return 0;
}
