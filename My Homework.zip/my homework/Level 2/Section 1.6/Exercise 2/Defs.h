//
//  Defs.h
//  C++ Exercise
//
//  Created by 胡雨昕 on 2019/8/28.
//  Copyright © 2019 胡雨昕. All rights reserved.
//

#ifndef Defs_h
#define Defs_h

#define MAX2(x,y) x>=y ? x:y

#define MAX3(x,y,z) MAX2(x,y)>=z ? MAX2(x,y):z

#endif /* Defs_h */
