//
//  MAX.c
//  C++ Exercise
//
//  Created by 胡雨昕 on 2019/8/28.
//  Copyright © 2019 胡雨昕. All rights reserved.
//

#include <stdio.h>
#include "Defs.h"

int main()
{
    printf("%d\n",MAX2(3,34));
    printf("%d\n",MAX3(3,100,34));
}
