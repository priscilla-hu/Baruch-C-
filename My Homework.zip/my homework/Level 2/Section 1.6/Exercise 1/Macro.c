//
//  Macro.c
//  C++ Exercise
//
//  Created by 胡雨昕 on 2019/8/28.
//  Copyright © 2019 胡雨昕. All rights reserved.
//

#include <stdio.h>
#include "Defs.h"

int main()
{
    char a,b;
    a='h';
    b='w';
    PRINT1(a); //use the fuctions defined in "Defs.h"
    PRINT2(a,b);
    return 0;
}
