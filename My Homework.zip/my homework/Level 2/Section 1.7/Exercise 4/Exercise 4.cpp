//
//  Exercise 4.cpp
//  C++ Exercise
//
//  Created by 胡雨昕 on 2019/8/29.
//  Copyright © 2019 胡雨昕. All rights reserved.
//

#include <stdio.h>

void DayName(int day);

int main()
{
    DayName(2);
    return 0;
}

void DayName(int day)
{
    char* weekday[7]; // an array of pointers
    weekday[0]="Sunday";
    weekday[1]="Monday";
    weekday[2]="Tuesday";
    weekday[3]="Wednesday";
    weekday[4]="Thursday";
    weekday[5]="Friday";
    weekday[6]="Saturday";
    printf("Day %d is a %s\n",day,weekday[day-1]);
}
