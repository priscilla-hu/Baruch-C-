//
//  Exercise 1.cpp
//  C++ Exercise
//
//  Created by 胡雨昕 on 2019/8/28.
//  Copyright © 2019 胡雨昕. All rights reserved.
//

#include <stdio.h>

void Swap(int* x,int* y);

int main()
{
    int i=123; int j=456;
    Swap(&i,&j);
    printf("%d, %d",i,j);
    return 0;
}

void Swap(int* x,int* y) //use pointer, otherwise only a copy of i,j is made
{
    int inter;
    inter=*x;  //change the value in the address of i,j
    *x=*y;
    *y=inter;
}
