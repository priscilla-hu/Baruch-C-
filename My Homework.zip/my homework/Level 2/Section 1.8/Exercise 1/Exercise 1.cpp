//
//  Exercise 1.cpp
//  C++ Exercise
//
//  Created by 胡雨昕 on 2019/8/29.
//  Copyright © 2019 胡雨昕. All rights reserved.
//

#include <stdio.h>

//declaration
void Print(struct Article* arg);

struct Article
{
    int Article_number;
    int Quantity;
    char Description[20];
};

//definition
void Print(struct Article* arg)
{
    printf("Article_number is %d\n",(*arg).Article_number);
    printf("Quantity is %d\n",(*arg).Quantity);
    printf("Description is %s\n",(*arg).Description);
}

//main
int main()
{
    struct Article atcl={3,5,"hello teacher"};
    Print(&atcl);
}
