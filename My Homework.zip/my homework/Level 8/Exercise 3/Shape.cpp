//
//  Shape.cpp
//  C++ Exercise
//
//

#include "Shape.hpp"
#include <sstream>
#include <stdlib.h>

using namespace std;

Shape::Shape(){  //default constructor
    id=rand();
}

Shape::Shape(const Shape& sp):id(sp.id){} //copy constructor

Shape::~Shape() //destructor
{
    //cout<<"Shape destructor"<<endl;
}

void Shape::operator =(const Shape& sp) //assignment operator
{
    id=sp.id;
}
string Shape::ToString() const //returns the id as string
{
    stringstream stream_id;
    string str_id;
    stream_id<<id;
    stream_id>>str_id;
    return("ID:"+str_id);
}
void Shape::Print() const
{
    cout<<ToString()<<endl;
}

