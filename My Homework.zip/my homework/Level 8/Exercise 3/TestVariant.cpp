//
//  TestVariant.cpp
//  C++ Exercise
//
//  Exercise 3: Variant

#include <boost/variant.hpp>
#include "Point.hpp"
#include "Line.hpp"
#include "Circle.hpp"
#include "Visitor.hpp"
#include <string>
#include <iostream>
using namespace std;

//create a typedef for a ShapeType variant that can contain a Point, Line or Circle.
typedef boost::variant<Point,Line,Circle> ShapeType;

//create a function that returns the variant.
ShapeType Create()
{
    ShapeType sp;
    
    cout<<"Please choose a shape type (A.Point/B.Line/C.Circle): "<<endl;
    char choice;
    cin>>choice;
    
    //create the requested shape type and return
    switch (choice)
    {
        case 'A':
            sp = Point();
            break;
        case 'B':
            sp = Line();
            break;
        case 'C':
            sp = Circle();
            break;
        default:
            break;
    }
    return sp;
}

int main()
{//call the function and print the result by sending it to cout
    ShapeType sp=Create();
    Line l;
    try{
        ShapeType spl=boost::get<Line>(sp);
    }
    catch (boost::bad_get& err)
    {
        cout<<"Error: "<<err.what()<<endl;
    }
    
    //move the shape
    Visitor vis;
    boost::apply_visitor(vis, sp);
    cout<<sp<<endl;
}

