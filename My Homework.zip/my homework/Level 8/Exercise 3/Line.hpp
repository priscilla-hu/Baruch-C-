//
//  Line.hpp
//
//

#ifndef Line_hpp
#define Line_hpp

#include <iostream>
#include "Point.hpp"
#include "Shape.hpp"
using namespace std;


class Line: public Shape
{
private:
    Point P1;
    Point P2;
public:
    Line(); //default constructor
    Line(Point& P1, Point& P2); //constructor with start and end point
    Line(Point P1, Point P2);
    ~Line();
    
    Line(const Line& ln);
    
    Point start() const;
    Point end() const;
    
    void start(Point& P1_new);
    void end(Point& P2_new);
    
    double Length() const;
    string ToString() const;
    Line operator =(const Line& ln); //assignment operator
    
    friend ostream& operator << (ostream& os,const Line& l);
    
    // add Draw() function
    void Draw() const;
};


#endif /* Line_hpp */

