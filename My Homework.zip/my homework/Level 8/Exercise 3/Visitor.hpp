//
//  Visitor.hpp
//  C++ Exercise
//
//  Created by 胡雨昕 on 2019/11/23.
//  Copyright © 2019 胡雨昕. All rights reserved.
//

#ifndef Visitor_hpp
#define Visitor_hpp

#include <boost/variant/static_visitor.hpp>
#include "Point.hpp"
#include "Line.hpp"
#include "Circle.hpp"

class Visitor: public boost::static_visitor<>
{
private:
    double m_dx;
    double m_dy;
    
public:
    Visitor():m_dx(1),m_dy(1){}
    
    Visitor(const Visitor& source):m_dx(source.m_dx),m_dy(source.m_dy){} //copy constructor
    
    Visitor(double xValue,double yValue):m_dx(xValue),m_dy(yValue){}
    
    ~Visitor(){};
    
    //Member operator overloading
    Visitor& operator = (const Visitor& source)
    {//assignment operator
        if (this==&source)
        {
            return *this;
        }
        m_dx=source.m_dx;
        m_dy=source.m_dy;
        return *this;
    }
    
    void operator () (Point& p) const
    {
        p.X(p.X()+m_dx);
        p.Y(p.Y()+m_dy);
    }
    void operator () (Line& l) const
    {
        Point p1=l.start();
        Point p2=l.end();
        p1.X(p1.X()+m_dx);
        p1.Y(p1.Y()+m_dy);
        p2.X(p2.X()+m_dx);
        p2.Y(p2.Y()+m_dx);
        l.start(p1);
        l.end(p2);
    }
    void operator () (Circle& c) const
    {
        Point center=c.CentrePoint();
        center.X(center.X()+m_dx);
        center.Y(center.Y()+m_dy);
        c.CentrePoint(center);
    }
};


#endif /* Visitor_hpp */
