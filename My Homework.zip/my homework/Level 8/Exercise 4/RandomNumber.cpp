//
//  RandomNumber.cpp
//  C++ Exercise
//
//  Exercise 4: Random Number Generation


#include <iostream>
#include <map>
#include <ctime>
#include <boost/random.hpp>
#include <boost/math/distributions/uniform.hpp>

using namespace std;

int main()
{
    // Throwing dice.
    // Mersenne Twister.
    boost::random::mt19937 myRng;
    // Set the seed.
    myRng.seed(static_cast<boost::uint32_t> (std::time(0))); // Uniform in range [1,6]
    boost::random::uniform_int_distribution<int> six(1,6);
    
    // Structure to hold outcome + frequencies
    map<int, long> statistics;
    int outcome;

    int n=1000000;
    cout<<"How many trials? "<<n<<endl;
    
    //perform the trials
    for (int i=0;i<n;i++){
        outcome = six(myRng);
        statistics[outcome]++;
    }
    
    //print out the result
    for (map<int,long>::const_iterator itr=statistics.begin();itr!=statistics.end();++itr)
    {
        cout<<"Trial "<<itr->first<<" has "<<setprecision(7)<<(double)(itr->second)/n*100<<"%"<<" outcomes"<<endl;
    }

}
