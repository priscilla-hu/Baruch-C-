//
//  Circle.cpp
//  C++ Exercise
//
//  Created by 胡雨昕 on 2019/9/11.
//  Copyright © 2019 胡雨昕. All rights reserved.
//

#include "Circle.hpp"
#include "cmath"
#include "sstream"

Circle::Circle():CentrePt(Point(0.0,0.0)),r(1.0),Shape(){}

Circle::Circle(Point& new_CentrePt, double new_r):CentrePt(new_CentrePt),r(new_r),Shape(){}

Circle::Circle(Point new_CentrePt, double new_r):CentrePt(new_CentrePt),r(new_r),Shape(){}

Circle::~Circle(){}

Circle& Circle::operator = (const Circle& source)
{
    if (this == &source)
    {
        return *this;
    }
    
    // call base class assignment
    Shape::operator = (source);
    
    //Copy state
    CentrePt=source.CentrePt;
    r=source.r;
    return *this;
}

ostream& operator << (ostream& os,const Circle& c)
{
    os << "Center: "<<c.CentrePt<<", Radius: "<<c.r;
    return os;
}

string Circle::ToString() const
{
    stringstream stream;
    std::string s=Shape::ToString();
    
    stream<<"Center: "<<CentrePt.ToString()<<", Radius:"<<r<<", "<<s;
    return stream.str();
}

void Circle::Draw() const
{
    cout<<"Draw a circle."<<endl;
}
