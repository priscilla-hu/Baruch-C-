//
//  TestSmartPointers.cpp
//  C++ Exercise
//
//  Exercise 1: Smart Pointers

#include <iostream>
#include "boost/shared_ptr.hpp"
#include "Array.hpp"
#include "Shape.hpp"
#include "Line.hpp"
#include "Point.hpp"
#include "Circle.hpp"

int main(){
    typedef boost::shared_ptr<Shape> ShapePtr;
    typedef Array<ShapePtr> ShapeArray;
    
    const int size=3;
    
    //create the shapes
    ShapePtr sp1(new Point(1,1));
    ShapePtr sp2(new Line(Point(0,0),Point(3,3)));
    ShapePtr sp3(new Circle(Point(0,0),1.0));
    {
        //create an array with shared pointers for shapes
        ShapeArray arr_shape(size);
        
        arr_shape[0]=sp1;
        arr_shape[1]=sp2;
        arr_shape[2]=sp3;
        
        //print the shapes
        for (int i=0;i<size;i++){
            cout<<(*(arr_shape[i])).ToString()<<endl;
        }
        cout<<sp1.use_count()<<endl;
        cout<<sp2.use_count()<<endl;
        cout<<sp3.use_count()<<endl;
    }
    
    //check whether the shapes have been automatically deleted
    cout<<sp1.use_count()<<endl;
    cout<<sp2.use_count()<<endl;
    cout<<sp3.use_count()<<endl;

}



