//
//  ArrayException.cpp
//  C++ Exercise
//
//  Created by 胡雨昕 on 2019/11/3.
//  Copyright © 2019 胡雨昕. All rights reserved.
//

#include "ArrayException.hpp"
#include <sstream>

using namespace std;

OutOfBoundException::OutOfBoundException(int i){index=i;}
OutOfBoundException::~OutOfBoundException(){}
std::string OutOfBoundException::GetMessage() const
{
    stringstream t;
    string result_t;
    t<<index;
    t>>result_t;
    return "The given index:"+result_t+" is out of bounds";
}
