//
//  Array.hpp
//  C++ Exercise
//
//  Created by 胡雨昕 on 2019/11/3.

//  add m_static_size and the function to set and get the default size
//

#ifndef Array_hpp
#define Array_hpp

#include <iostream>

template <typename T>
class Array
{
private:
    T* m_data;
    int m_size=10;
    static int m_static_size; // Static member indicating the default size
public:
    Array();//constructor
    Array(int size);
    Array(const Array<T>& a);//copy constructor
    ~Array();
    
    //functions
    int Size() const;//selector
    int DefaultSize() const;//get the default size
    void DefaultSize(int s);//set the default size
    void SetElement(int index,T pt);//modifier
    T GetElement(int index) const;
    
    //operators
    Array<T> operator = (const Array<T>& source);//assignment operator
    
    T& operator[](int index);
    const T& operator [] (int index) const;
};

//Tip: by placing the following code at the end of the array header file, but before the header file’s #endif, the client can keep including the header file for template classes instead of the source file. Can you explain how this works?

//Explanation: Because when the hpp file is included, whether cpp file has been included will be checked by the following code. If the souce file has not been included yet, then "Array.cpp" will be included. By including the header file in the test program, the source file will also be included.

#ifndef Array_cpp // Must be the same name as in source file #define
#include "Array.cpp"
#endif

#endif /* Array_hpp */
