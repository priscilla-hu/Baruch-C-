//
//  Circle.hpp
//  C++ Exercise
//
//

#ifndef Circle_hpp
#define Circle_hpp

#include <iostream>
#include "Shape.hpp"
#include "Point.hpp"

using namespace std;

class Circle:public Shape
{
private:
    Point CentrePt;
    double r;
    
public:
    //constructor and disructor
    Circle();
    Circle(Point& CentrePt, double r);
    Circle(Point CentrePt, double r);
    virtual ~Circle();
    
    //Member operator overloading
    Circle& operator = (const Circle& source); //assignment operator
    
    //Global operator overloading
    friend ostream& operator << (ostream& os, const Circle& c); //Send to ostream
    string ToString() const;
    
    //Functionalities
    void Draw() const;

};

#endif /* Circle_hpp */
