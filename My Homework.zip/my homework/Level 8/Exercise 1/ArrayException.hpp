//
//  ArrayException.hpp
//  C++ Exercise
//
//  Created by 胡雨昕 on 2019/11/3.
//  Copyright © 2019 胡雨昕. All rights reserved.
//

#ifndef ArrayException_hpp
#define ArrayException_hpp

#include <iostream>

//error
class ArrayException
{
public:
    virtual std::string GetMessage() const=0;
};

class OutOfBoundException:public ArrayException
{
private:
    int index;
public:
    OutOfBoundException(int i);
    ~OutOfBoundException();
    std::string GetMessage() const;
};


#endif /* ArrayException_hpp */
