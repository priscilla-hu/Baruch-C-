//
//  PersonTuple.cpp
//  C++ Exercise
//
//  Exercise 2: Tuple


#include <iostream>
#include <boost/tuple/tuple.hpp>
#include <boost/tuple/tuple_io.hpp>

#include <string>
#include <iostream>
using namespace std;

// create a function that prints the person tuple.
void Print_tuple(const boost::tuple<string,int,double>& person)
{
    cout<<"name: "<<person.get<0>()<<", age: "<<person.get<1>()<<", height: "<<person.get<2>()<<endl;
}

int main(){
    using boost::tuple;
    
    //create a typedef for a Person tuple that contains a name, age and length.
    typedef tuple<string,int,int> Person;
    
    //create person instances
    Person pr1(string("Priscilla"),20,170);
    Person pr2(string("Mike"),25,180);
    Person pr3(string("Jack"),10,140);
    
    //print the tuple
    Print_tuple(pr1);
    Print_tuple(pr2);
    Print_tuple(pr3);
    
    //increment the age of pr1
    pr1.get<1>()+=2;
    
    //print the tuple again
    Print_tuple(pr1);
    Print_tuple(pr2);
    Print_tuple(pr3);
    
    return 0;
    
}
