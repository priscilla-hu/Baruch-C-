//
//  Exercise 1.cpp
//  C++ Exercise
//
//  Created by 胡雨昕 on 2019/8/27.
//  Copyright © 2019 胡雨昕. All rights reserved.
//

#include <stdio.h>

float my_minus(float arg1,float arg2);

int main()
{
    float n1=3;
    float n2=5;
    printf("%f\n",my_minus(n1,n2));
}

float my_minus(float arg1,float arg2)
{
    return arg1-arg2;
}
