//
//  Exercise 2.cpp
//  C++ Exercise
//
//  Created by 胡雨昕 on 2019/8/27.
//  Copyright © 2019 胡雨昕. All rights reserved.
//

#include <stdio.h>

long fac(unsigned int x);

long fac(unsigned int x)
{
    if (x==0)
    {
        return x;
    }
    return x*fac(x-1);
}


int main()
{
    unsigned int n;
    scanf("%d",&n);
    printf("%d\n",fac(n));

}
