//
//  Exercise 4.cpp
//  C++ Exercise
//
//  Created by 胡雨昕 on 2019/8/27.
//  Copyright © 2019 胡雨昕. All rights reserved.
//

#include <stdio.h>

void printnumber(int number);

int main()
{
    int n=-1234;
    if (n<0){
        putchar('-');
        printnumber(-n);
    }
    else{
        printnumber(n);
    }
    return 0;
}

void printnumber(int number)
{
    if (number/10)
        printnumber(number/10);
    putchar('0'+number%10);
}
