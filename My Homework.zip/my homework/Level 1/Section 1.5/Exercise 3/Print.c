//
//  Print.c
//  C++ Exercise
//
//  Created by 胡雨昕 on 2019/8/27.
//  Copyright © 2019 胡雨昕. All rights reserved.
//

#include <stdio.h>

int print(int number)
{
    printf("%d\n",number*2);
    return number*2;
}
