//
//  Main.c
//  C++ Exercise
//
//  Created by 胡雨昕 on 2019/8/27.
//  Copyright © 2019 胡雨昕. All rights reserved.
//

#include <stdio.h>

int print(int number);

int main()
{
    int i=3;
    print(i);
    return 0;
}
