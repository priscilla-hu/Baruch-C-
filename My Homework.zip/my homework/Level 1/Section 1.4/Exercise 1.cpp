//
//  Exercise 1.cpp
//  C++ Exercise
//
//  Created by 胡雨昕 on 2019/8/27.
//  Copyright © 2019 胡雨昕. All rights reserved.
//

#include <stdio.h>


int main()
{
    int characters,words,lines;
    char ch;
    char str[1024];
    
    characters=words=lines=0;
    while ((ch=getchar())!=EOF)
    {
        if (ch=='\n')
        {
            lines++;
        }
        if ((str[characters-1]!=' ')&(ch==' '||ch=='\n'))
        {
            words++;
        }
        str[characters]=ch;
        characters++; // '/n' and ' ' are also taken as characters
        
    }
    printf("%d characters\n",characters);
    printf("%d words\n",words);
    printf("%d lines\n",lines);
    return 0;

}









