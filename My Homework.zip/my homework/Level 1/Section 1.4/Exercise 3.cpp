//
//  Exercise 3.cpp
//  C++ Exercise
//
//  Created by 胡雨昕 on 2019/8/27.
//  Copyright © 2019 胡雨昕. All rights reserved.
//

#include <stdio.h>

int main()
{
    int characters,words,lines;
    char ch,ch_last;
    
    characters=words=lines=0;
    ch_last='0';
    while ((ch=getchar())!=4)
    {
        switch(ch)
        {
            case '\n':
                lines++;
                switch(ch_last)
                {
                    case ' ':
                        break;
                    default:
                        words++;break;
                }
            case ' ':
                switch(ch_last)
                {
                    case ' ':
                        break;
                    default:
                        words++;break;
                }
        }
        ch_last=ch;
        characters++; // '/n' and ' ' are also taken as characters
        
    }
    printf("%d characters\n",characters);
    printf("%d words\n",words);
    printf("%d lines\n",lines);
    return 0;
}
