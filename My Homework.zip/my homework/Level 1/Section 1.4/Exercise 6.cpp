//
//  Exercise 6.cpp
//  C++ Exercise
//
//  Created by 胡雨昕 on 2019/8/27.
//  Copyright © 2019 胡雨昕. All rights reserved.
//

#include <stdio.h>

int main()
{
    char ch;
    int n0,n1,n2,n3,n4,n_other;
    n0=n1=n2=n3=n4=n_other=0;
    
    while(EOF!=(ch=getchar()))
    {
        switch(ch)
        {
            case '0':
                n0++;break;
            case '1':
                n1++;break;
            case '2':
                n2++;break;
            case '3':
                n3++;break;
            case '4':
                n4++;break;
            default:
                n_other++;break;
        }
    }
    printf("0 appears %d times\n",n0);
    printf("1 appears %d times\n",n1);
    printf("2 appears %d times\n",n2);
    printf("3 appears %d times\n",n3);
    printf("4 appears %d times\n",n4);
    printf("others appears %d times\n",n_other);
}
