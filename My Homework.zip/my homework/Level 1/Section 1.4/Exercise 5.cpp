//
//  Exercise 5.cpp
//  C++ Exercise
//
//  Created by 胡雨昕 on 2019/8/27.
//  Copyright © 2019 胡雨昕. All rights reserved.
//

#include <stdio.h>

int main()
{
    double start,f,end,step,c;
    long i;
    start=0;
    end=19;
    step=1;
    c=start;
    
    printf("%10s  %10s\n","Celsius","Fahrenheit");
    for(i=0;i<=(end-start)/step;i++)
    {
        f=c*9/5+32;
        printf("%10.1f, %10.1f\n",c,f);
        c+=step;
    }
    return 0;
}
