//
//  Exercise 7.cpp
//  C++ Exercise
//
//  Created by 胡雨昕 on 2019/8/27.
//  Copyright © 2019 胡雨昕. All rights reserved.
//

#include <stdio.h>

int main()
{
    int count=0;
    char ch;
    while((ch=getchar())!= EOF)
    {
        switch(ch)
        {
            case '3':
                count++;break;
            default:
                break;
        }
    }
    if (count>=3)
    {
        printf("The number three appears more than two times.\n");
    }
    else if (count==2)
    {
        printf("The number three appears two times.\n");
    }
    else if (count==1)
    {
        printf("The number three appears one time.\n");
    }
    else if (count==0)
    {
        printf("The number three appears zero time.\n");
    }
}
