//
//  1.3.cpp
//  C++ Exercise
//
//  Created by 胡雨昕 on 2019/8/25.
//  Copyright © 2019 胡雨昕. All rights reserved.
//

#include <stdio.h>
int main()
{
    printf("My first C-program\nis a fact!\nGood, isn’t it?");
    return 0;
}
