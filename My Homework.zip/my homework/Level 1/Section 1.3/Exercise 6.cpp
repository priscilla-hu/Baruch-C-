//
//  Exercise 6.cpp
//  C++ Exercise
//
//  Created by 胡雨昕 on 2019/8/27.
//  Copyright © 2019 胡雨昕. All rights reserved.
//

#include <stdio.h>

int main()
{
    int i;
    scanf("%d",&i);
    i=i >> 2;
    printf("%d\n",i);
    
    if (i<0)
    {
        printf("a 1 is inserted left\n");
    }
    else
    {
        printf("a 0 is inserted left\n");
    }
}
