//
//  1.3.2.cpp
//  C++ Exercise
//
//  Created by 胡雨昕 on 2019/8/25.
//  Copyright © 2019 胡雨昕. All rights reserved.
//

#include <stdio.h>

int main()
{
    float height;
    float base;
    float s;
    scanf("%f",&height);
    scanf("%f",&base);
    s=(height*base)*0.5;
    printf("%f",s);
    return 0;
    
}
