//
//  1.3.5.cpp
//  C++ Exercise
//
//  Created by 胡雨昕 on 2019/8/25.
//  Copyright © 2019 胡雨昕. All rights reserved.
//

# include <stdio.h>

int main()
{
    int res1,res2;int a=2;
    res1=a++;
    res2=++a;
    printf("%d\n",res1);
    printf("%d\n",res2);
    return 0;
}
