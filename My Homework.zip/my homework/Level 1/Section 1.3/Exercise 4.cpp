//
//  Exercise 4.cpp
//  C++ Exercise
//
//  Created by 胡雨昕 on 2019/9/1.
//  Copyright © 2019 胡雨昕. All rights reserved.
//

#include <stdio.h>

int main()
{
    int married=0 ? printf("married\n"):printf("not married\n");
}
