//
//  Exercise 7.cpp
//  C++ Exercise
//
//  Created by 胡雨昕 on 2019/8/27.
//  Copyright © 2019 胡雨昕. All rights reserved.
//

#include <stdio.h>

int main()
{
    int x=10;
    int n=4;
    x=x<<n;
    printf("%d\n",x);
    return 0;
}
