//
//  TestOptionA_b.cpp
//  C++ Exercise
//
//  Test Part B: Option sensitivity
//  1. Implement the above formulae for gamma for call and put future option pricing using the data set: K = 100, S = 105, T = 0.5, r = 0.1, b = 0 and sig = 0.36.
//  2. compute call delta price for a monotonically increasing range of underlying values of S, for example 10, 11, 12, ..., 50.
//  3. Incorporate this into your above matrix pricer code
//  4. use divided differences to approximate option sensitivities

#include <iostream>
#include "Option.hpp"
#include <cmath>
#include <vector>
using namespace std;

// global fucntion
vector<double> Mesh(double begin,double end,int n)
{
    vector<double> vecMesh;
    double step=(end-begin)/n;
    for (int i=0;i<n+1;i++) {vecMesh.push_back(begin+step*i);}
    return vecMesh;
}

//print vector
void print(const vector<double>& vec)
{
    for (size_t i=0;i<vec.size();++i)
    {
        cout<<vec[i]<<",";
    }
    cout<<endl;
}

//print matrix
void print(const vector<vector<double>>& matrix)
{
    cout<<endl;
    for (size_t i=0;i<matrix.size();++i)
    {
        print(matrix[i]);
    }
    cout<<endl;
}



int main()
{
    //K = 100, S = 105, T = 0.5, r = 0.1, b = 0 and sig = 0.36.
    //(exact delta call = 0.5946, delta put = -0.3566).

    vector<double> bt(6);
    //T K sig r S b
    bt[0]=0.5;bt[1]=100;bt[2]=0.36;bt[3]=0.1;bt[4]=105;bt[5]=0;
    
    //2.a implement the formulae for gamma
    double delta,gamma;

    Option op1(bt);
    delta=op1.Delta();
    gamma=op1.Gamma();
    cout<<"Call Delta: "<<delta<<", Call Gamma: "<<gamma<<endl;
    op1.toggle();
    delta=op1.Delta();
    gamma=op1.Gamma();
    cout<<"Put Delta: "<<delta<<", Put Gamma: "<<gamma<<endl;
    
    //2.b compute call delta price for a monotonically increasing range of S
    vector<double> vecS=Mesh(10,50,40);
    vector<double> vecDCall(41);
    vector<double> vecDPut(41);
    Option op2(bt);
    op2.optType="C";
    for (int i=0;i<vecS.size();i++)
    {
        op2.S=vecS[i];
        vecDCall[i]=op2.Price();
    }
    op2.toggle();
    for (int i=0;i<vecS.size();i++)
    {
        op2.S=vecS[i];
        vecDPut[i]=op2.Price();
    }
    cout<<"\nRange of S: ";
    print(vecS);
    cout<<"\nCall price: ";
    print(vecDCall);
    cout<<"\nPut price: ";
    print(vecDPut);
    
    //2.c input matrix
    //create a input matrix
    vector<vector<double>> opParam(41);
    for (int i=0;i<41;i++)
    {
        opParam[i].push_back(0.25); //T
        opParam[i].push_back(65);   //K
        opParam[i].push_back(0.3);  //sig
        opParam[i].push_back(0.08); //r
        opParam[i].push_back(60);   //S
        opParam[i].push_back(0.08); //b
    }
    
    //expiry time
    vector<vector<double>> opParamT=opParam;
    vector<double> vecT=Mesh(0.25,30,40);
    for (int i=0;i<41;i++)
    {
        opParamT[i][0]=vecT[i]; //T
    }
    Option optT;
    cout<<"\nInput matrix(different T):";
    print(opParamT);
    cout<<"\nDelta corresponding to the input matirx:";
    print(optT.Delta(opParamT));
    cout<<"\nGamma corresponding to the input matirx:";
    print(optT.Gamma(opParamT));
    
    //volatillity
    vector<vector<double>> opParamV=opParam;
    vector<double> vecV=Mesh(0.1,1,40);
    for (int i=0;i<41;i++)
    {
        opParamV[i][2]=vecV[i]; //sig
    }
    Option optV;
    cout<<"\nInput matrix(different T):";
    print(opParamV);
    cout<<"\nDelta corresponding to the input matirx:";
    print(optT.Delta(opParamV));
    cout<<"\nGamma corresponding to the input matirx:";
    print(optT.Gamma(opParamV));

    //2.d approximate option sensitivities
    
    // h= 0.049
    Option op3(bt);
    vector<double> vecH1=Mesh(0.01,0.5,10);
    vector<double> vecD(11),vecG(11);
    for (int i=0;i<11;i++)
    {
        vecD[i]=op3.DeltaHat(vecH1[i]);
        vecG[i]=op3.GammaHat(vecH1[i]);
    }
    cout<<"h=0.049"<<endl;
    cout<<"Delta: ";
    print(vecD);
    cout<<"Gamma: ";
    print(vecG);
    
    // h= 0.019
    Option op4(bt);
    vector<double> vecH2=Mesh(0.01,0.2,10);
    for (int i=0;i<11;i++)
    {
        vecD[i]=op3.DeltaHat(vecH2[i]);
        vecG[i]=op3.GammaHat(vecH2[i]);
    }
    cout<<"h=0.019"<<endl;
    cout<<"Delta: ";
    print(vecD);
    cout<<"Gamma: ";
    print(vecG);
    
}

