//
//  Option.hpp
//  C++ Exercise
//
//  Created by 胡雨昕 on 2019/11/27.
//  Copyright © 2019 胡雨昕. All rights reserved.
//

#ifndef Option_hpp
#define Option_hpp

#include <iostream>
#include <string>
#include <vector>
using namespace std;

class Option
{
private:
    void init();
    Option copy(const Option& newOp);
    
    //kernel functions for option calculations
    double CallPrice() const;
    double PutPrice() const;
    double CallDelta() const;
    double PutDelta() const;
    double CallGamma() const;
    double PutGamma() const;
    
    //gaussian function
    double n(double x) const;
    double N(double x) const;
    
public:
    double T;   //expiry date
    double K;   //strike price
    double sig; //vollatility
    double r;   //interest rate
    double S;   //strike price
    double b;   //cost of carry
    
    string optType;
    string unam;    //Name of underlying asset

    //constructors and destructor
    Option();
    Option(const vector<double> param); //use six parameters
    Option(const Option& opNew);
    ~Option();
    
    Option& operator=(const Option& opNew);
    
    //Option price and sensitivities
    double Price() const;
    double Price(const vector<double> param);
    vector<double> Price(const vector<vector<double>> param);
    
    double Delta() const;
    double Delta(const vector<double> param);
    vector<double> Delta(const vector<vector<double>> param);
    
    double Gamma() const;
    double Gamma(const vector<double> param);
    vector<double> Gamma(const vector<vector<double>> param);
    
    //approximate Delta and Gamma
    double DeltaHat(double h);
    double GammaHat(double h);
    
    //put-call parity relationship
    double CallToPut(double c) const;
    double PutToCall(double p) const;
    
    //modifier functions
    void toggle();
    
};


#endif /* Option_hpp */
