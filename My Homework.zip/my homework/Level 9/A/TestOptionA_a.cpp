//
//  TestOption.cpp
//  C++ Exercise
//
//  Test Part A: Option price

//  1. Implement the above formulae for call and put option pricing using the data sets Batch 1 to Batch 4.
//  2. Applytheput-callparityrelationshiptocomputecallandputoptionprices.
//  3. compute option prices for a monotonically increasing range of underlying values of S
//  4. extend part c and compute option prices as a function of i) expiry time, ii) volatility, or iii) any of the option pricing parameters.

#include <iostream>
#include "Option.hpp"
#include <cmath>
#include <vector>
using namespace std;

// global fucntion
vector<double> Mesh(double begin,double end,int n)
{
    vector<double> vecMesh;
    double step=(end-begin)/n;
    for (int i=0;i<n+1;i++) {vecMesh.push_back(begin+step*i);}
    return vecMesh;
}

//print vector
void print(const vector<double>& vec)
{
    for (size_t i=0;i<vec.size();++i)
    {
        cout<<vec[i]<<",";
    }
    cout<<endl;
}

//print matrix
void print(const vector<vector<double>>& matrix)
{
    cout<<endl;
    for (size_t i=0;i<matrix.size();++i)
    {
        print(matrix[i]);
    }
    cout<<endl;
}



int main()
{
    
    //batch1-4
    // the order of the elements in the vector: T, K, sig, r, S, b
    vector<double> bt1(6),bt2(6),bt3(6),bt4(6);
    bt1[0]=1.65;bt1[1]=122;bt1[2]=0.43;bt1[3]=0.045;bt1[4]=102;bt1[5]=0;
    bt2[0]=1;bt2[1]=100;bt2[2]=0.2;bt2[3]=0;bt2[4]=100;bt2[5]=0;
    bt3[0]=1;bt3[1]=10;bt3[2]=0.5;bt3[3]=0.12;bt3[4]=5;bt3[5]=0.12;
    bt4[0]=30;bt4[1]=100;bt4[2]=0.3;bt4[3]=0.08;bt4[4]=100;bt4[5]=0.08;
    
    //1.a implement the formulae for call and put option pricing
    double pCall1,pCall2,pCall3,pCall4;
    double pPut1,pPut2,pPut3,pPut4;
    double deltaC,gammaC,deltaP,gammaP;
    
    Option op1(bt1);
    pCall1=op1.Price();
    deltaC=op1.Delta();
    gammaC=op1.Gamma();
    
    op1.toggle();
    
    pPut1=op1.Price();
    deltaP=op1.Delta();
    gammaP=op1.Gamma();
    
    cout<<"Batch1:"<<endl;
    cout<<"Call Delta: "<<deltaC<<", Call Gamma: "<<gammaC<<endl;
    cout<<"Put Delta: "<<deltaP<<", Put Gamma: "<<gammaP<<endl;
    cout<<"Call: "<<pCall1<<", Put: "<<pPut1<<endl;
    
    Option op2(bt2);
    pCall2=op2.Price();
    op2.toggle();
    pPut2=op2.Price();
    cout<<"Batch2:"<<endl;
    cout<<"Call: "<<pCall2<<", Put: "<<pPut2<<endl;
    
    Option op3(bt3);
    pCall3=op3.Price();
    op3.toggle();
    pPut3=op3.Price();
    cout<<"Batch3:"<<endl;
    cout<<"Call: "<<pCall3<<", Put: "<<pPut3<<endl;
    
    Option op4(bt4);
    pCall4=op4.Price();
    op4.toggle();
    pPut4=op4.Price();
    cout<<"Batch4:"<<endl;
    cout<<"Call: "<<pCall4<<", Put: "<<pPut4<<endl;
    
    //1.b put-call parity relationship
    
    // use the parity relationship to calculate the corresponding price
    cout<<"Batch1:"<<endl;
    cout<<"Call to Put: "<<op1.CallToPut(pCall1)<<endl;
    cout<<"Put to Call: "<<op1.PutToCall(pPut1)<<endl;
    // check if a given set of price satisfy parity
    cout<<"check: "<<((pCall1+op1.K*exp(-op1.r*op1.T))==(pPut1+op1.S))<<endl;
    
    cout<<"Batch2:"<<endl;
    cout<<"Call to Put: "<<op2.CallToPut(pCall2)<<endl;
    cout<<"Put to Call: "<<op2.PutToCall(pPut2)<<endl;
    cout<<"check: "<<((pCall2+op2.K*exp(-op2.r*op2.T))==(pPut2+op2.S))<<endl;
    
    cout<<"Batch3:"<<endl;
    cout<<"Call to Put: "<<op3.CallToPut(pCall3)<<endl;
    cout<<"Put to Call: "<<op3.PutToCall(pPut3)<<endl;
    cout<<"check: "<<((pCall3+op3.K*exp(-op3.r*op3.T))==(pPut3+op3.S))<<endl;
    
    cout<<"Batch4:"<<endl;
    cout<<"Call to Put: "<<op4.CallToPut(pCall4)<<endl;
    cout<<"Put to Call: "<<op4.PutToCall(pPut4)<<endl;
    cout<<"check: "<<((pCall4+op4.K*exp(-op4.r*op4.T))==(pPut4+op4.S))<<endl;
    
    
    //1.c monotonically increasing S, use batch1 as an example
    vector<double> vecS=Mesh(10,50,40);
    vector<double> vecPCall(41);
    vector<double> vecPPut(41);
    op1.optType="C";
    for (int i=0;i<vecS.size();i++)
    {
        op1.S=vecS[i];
        vecPCall[i]=op1.Price();
    }
    op1.toggle();
    for (int i=0;i<vecS.size();i++)
    {
        op1.S=vecS[i];
        vecPPut[i]=op1.Price();
    }
    cout<<"\nRange of S: ";
    print(vecS);
    cout<<"\nCall price: ";
    print(vecPCall);
    cout<<"\nPut price: ";
    print(vecPPut);
    
    //1.d input a matrix
    
    //create a input matrix
    vector<vector<double>> opParam(41);
    for (int i=0;i<41;i++)
    {
        opParam[i].push_back(0.25); //T
        opParam[i].push_back(65);   //K
        opParam[i].push_back(0.3);  //sig
        opParam[i].push_back(0.08); //r
        opParam[i].push_back(60);   //S
        opParam[i].push_back(0.08); //b
    }
    
    //expiry time
    vector<vector<double>> opParamT=opParam;
    vector<double> vecT=Mesh(0.25,30,40);
    for (int i=0;i<41;i++)
    {
        opParamT[i][0]=vecT[i]; //T
    }
    Option optT;
    cout<<"\nInput matrix(different T):";
    print(opParamT);
    cout<<"\nThe price vector corresponding to the input matirx:";
    print(optT.Price(opParamT));
    
    //volatillity
    vector<vector<double>> opParamV=opParam;
    vector<double> vecV=Mesh(0.1,1,40);
    for (int i=0;i<41;i++)
    {
        opParamV[i][2]=vecV[i]; //sig
    }
    Option optV;
    cout<<"\nInput matrix(different V):";
    print(opParamV);
    cout<<"\nThe price vector corresponding to the input matirx:";
    print(optV.Price(opParamV));

}
