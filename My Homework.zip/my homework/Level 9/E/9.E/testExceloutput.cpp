//
//  TestOption.cpp
//  C++ Exercise
//
//  Test Part A: Option price

//  1. Implement the above formulae for call and put option pricing using the data sets Batch 1 to Batch 4.
//  2. Applytheput-callparityrelationshiptocomputecallandputoptionprices.
//  3. compute option prices for a monotonically increasing range of underlying values of S
//  4. extend part c and compute option prices as a function of i) expiry time, ii) volatility, or iii) any of the option pricing parameters.

#include <iostream>
#include "Option.hpp"
#include "UtilitiesDJD/VectorsAndMatrices/Vector.cpp"
#include "UtilitiesDJD/ExcelDriver/ExcelMechanisms.hpp"
#include "UtilitiesDJD/Geometry/Range.cpp"
#include "UtilitiesDJD/ExceptionClasses/DatasimException.hpp"
#include <cmath>
#include <list>
#include <boost/tuple/tuple.hpp>
#include <boost/tuple/tuple_io.hpp>
#include <vector>
#include <fstream>
#include <string>

using namespace std;

// global fucntion

std::vector<double> mesher(double begin, double end, int n){
	double step = (end - begin) / n;

	vector<double> xarr(n+1);
	xarr[0] = begin;
	xarr[xarr.size()-1] = end;

	for (int n = 1; n < xarr.size(); n++){
		xarr[n] = xarr[n - 1] + step;
	}

	return xarr;
}


//print vector
void print(const vector<double>& vec)
{
    for (size_t i=0;i<vec.size();++i)
    {
        cout<<vec[i]<<",";
    }
    cout<<endl;
}

//print matrix
void print(const vector<vector<double>>& matrix)
{
    cout<<endl;
    for (size_t i=0;i<matrix.size();++i)
    {
        print(matrix[i]);
    }
    cout<<endl;
}

//print Vector
void print(const Vector<double,long>&vect)
{
	cout << endl;
	for (size_t i = vect.MinIndex(); i<vect.MaxIndex(); ++i)
	{
		cout<<vect[i]<<",";
	}
	cout << endl;
}

string graphname[5] = {"", "Graph 1", "Graph 2", "Graph 3", "Graph 4"};

void operate(vector<double> bt,int id) {

	// a implement for call and put option pricing
	double pCall1, pCall2, pCall3, pCall4;
	double pPut1, pPut2, pPut3, pPut4;
	Option op1(bt);
	pCall1 = op1.Price();
	op1.toggle();
	pPut1 = op1.Price();
	cout << "\n***************************\n" ;
	cout << "Batch" << id << ":" <<endl;
	cout << "Call: " << pCall1 << ", Put: " << pPut1 << endl;


	// monotonically increasing S, use batch1 as an example
	vector<double> vecS = mesher(10, 50, 40);
	Vector<double, long> X(vecS.size(), 0.0);
	Vector<double, long> vecPCall(41, 0.0);
	Vector<double, long> vecPPut(41, 0.0);
	op1.optType = "C";
	for (int i = 0; i<vecS.size(); i++)
	{
		X[i] = vecS[i];
		op1.S = vecS[i];
		double t = op1.Price();
		vecPCall[i] = t;
	}
	op1.toggle();
	for (int i = 0; i<vecS.size(); i++)
	{
		X[i] = vecS[i];
		op1.S = vecS[i];
		vecPPut[i] = op1.Price();
	}

	cout << "\nRange of S: ";
	print(vecS);
	cout << "\nCall price: ";
	print(vecPCall);
	cout << "\nPut price: ";
	print(vecPPut);
	cout << "Data has been created" << endl;


	std::list<std::string> labels; // Call/Put
	std::list<Vector<double, long>> result; // list of Price values

	result.push_back(vecPCall);
	result.push_back(vecPPut);

	// Name of the two lines
	labels.push_back("PCall");
	labels.push_back("PPut");

	// Print the results in Excel.
    try
    {
        printInExcel(X, labels, result,
            string(graphname[id]), string("S (Asset Price)"), string("Option Price"));
    }
    catch (DatasimException& e)
    {
        e.print();
    }
}

void run() {
    vector<double> bt1(6),bt2(6),bt3(6),bt4(6);
    bt1[0]=0.25;bt1[1]=65;bt1[2]=0.3;bt1[3]=0.08;bt1[4]=60;bt1[5]=0.08;
    bt2[0]=1;bt2[1]=100;bt2[2]=0.2;bt2[3]=0;bt2[4]=100;bt2[5]=0;
    bt3[0]=1;bt3[1]=10;bt3[2]=0.5;bt3[3]=0.12;bt3[4]=5;bt3[5]=0.12;
    bt4[0]=30;bt4[1]=100;bt4[2]=0.3;bt4[3]=0.08;bt4[4]=100;bt4[5]=0.08;

	operate(bt1, 1);
	operate(bt2, 2);
	operate(bt3, 3);
	operate(bt4, 4);
}

int main()
{
	run();
	system("pause");
	return 0;
}
