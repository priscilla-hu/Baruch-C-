//
//  Option.cpp
//  C++ Exercise
//
//  Created by 胡雨昕 on 2019/11/27.
//  Copyright © 2019 胡雨昕. All rights reserved.
//

#include "Option.hpp"
#include <cmath>

//gaussian function
#include <boost/math/distributions/normal.hpp>
#include <boost/math/distributions.hpp>
//gaussian function
using namespace boost::math;
double N_BOOST(double x)
{

	normal_distribution<> StdNormal(0.0, 1.0);

	return cdf(StdNormal, x);

}

double n_BOOST(double x)
{

	normal_distribution<> StdNormal(0.0, 1.0);

	return pdf(StdNormal, x);

}
double Option::n(double x) const
{
    double A=1/sqrt(2*3.1415);
    return A*exp(-x*x*0.5);
}

double Option::N(double x) const
{
    double a1=0.4361836;
    double a2=-0.1201676;
    double a3=0.9372980;
    double k = 1.0/(1.0 + (0.33267 * x));
    if (x >= 0.0)
    {
        return 1.0 - n(x)* (a1*k + (a2*k*k) + (a3*k*k*k));
    }
    else
    {
        return 1.0 - N(-x);
    }
}

// default initialization
void Option::init()
{
    T=0.5;  //expiry date
    K=110.0;   //strike price
    sig=0.2; //vollatility
    r=0.05;   //interest rate
    S=60;   //strike price
    b=r;   // Black and Scholes stock option model (1973)
    optType="C";
}

//copy
Option Option::copy(const Option& newOp)
{
    T=newOp.T;  //expiry date
    K=newOp.K;   //strike price
    sig=newOp.sig; //vollatility
    r=newOp.r;   //interest rate
    S=newOp.S;   //strike price
    b=newOp.b;   // Black and Scholes stock option model (1973)
    optType=newOp.optType;
    return *this;
}

//kernel functions for option calculations
double Option::CallPrice() const
{
    double tmp=sig*sqrt(T);
    double d1=(log(S/K)+(b+sig*sig*0.5)*T)/tmp;
    double d2=d1-tmp;
    
    return (S*exp((b-r)*T)*N_BOOST(d1))-(K*exp(-r*T)*N_BOOST(d2));
}

double Option::PutPrice() const
{
    double tmp = sig * sqrt(T);
    double d1 = ( log(S/K) + (b+ (sig*sig)*0.5 ) * T )/ tmp;
    double d2 = d1 - tmp;
    
    return (K * exp(-r * T)* N(-d2)) - (S * exp((b-r)*T) * N(-d1));
}

double Option::CallDelta() const
{
    double tmp=sig*sqrt(T);
    double d1 = ( log(S/K) + (b+ (sig*sig)*0.5 ) * T )/ tmp;
    
    return exp((b-r)*T)*N(d1);
}

double Option::PutDelta() const
{
    double tmp = sig * sqrt(T);
    double d1 = ( log(S/K) + (b+ (sig*sig)*0.5 ) * T )/ tmp;
    
    return exp((b-r)*T) * (N(d1) - 1.0);
}

double Option::CallGamma() const
{
    double tmp=sig * sqrt(T);
    double d1 = ( log(S/K) + (b+ (sig*sig)*0.5 ) * T )/ tmp;
    
    return n(d1)*exp((b-r)*T)/(S*tmp);
}

double Option::PutGamma() const
{
    return CallGamma();
}


//constructors and destructor
Option::Option()
{
    init();
}

Option::Option(const vector<double> param)
{
    init();
    T=param[0];
    K=param[1];
    sig=param[2];
    r=param[3];
    S=param[4];
    b=param[5];
}

Option::Option(const Option& opNew)
{
    copy(opNew);
}

Option::~Option(){}

Option& Option::operator=(const Option& opNew) //assignment operator
{
    if (this==&opNew){return *this;}
    copy(opNew);
    return *this;
}

//Option price and sensitivities
double Option::Price() const
{
    if (optType == "C")
    {
        //cout << "calling call\n";
        return CallPrice();
    }
    else
    {
        //cout << "calling put\n";
        return PutPrice();
    }
}
double Option::Price(const vector<double> param)
{
    T=param[0];
    K=param[1];
    sig=param[2];
    r=param[3];
    S=param[4];
    b=param[5];
    return Price();
}

vector<double> Option::Price(const vector<vector<double>> param)
{
    vector<double> vecP(param.size());
    for (int i=0;i<vecP.size();i++)
    {
        vecP[i]=Price(param[i]);
    }
    return vecP;
}

double Option::Delta() const
{
    if (optType == "C")
        return CallDelta();
    else
        return PutDelta();
}

double Option::Delta(const vector<double> param)
{
    T=param[0];
    K=param[1];
    sig=param[2];
    r=param[3];
    S=param[4];
    b=param[5];
    return Delta();
}

vector<double> Option::Delta(const vector<vector<double>> param)
{
    vector<double> vecD(param.size());
    for (int i=0;i<vecD.size();i++)
    {
        vecD[i]=Delta(param[i]);
    }
    return vecD;
}

double Option::Gamma() const
{
    if (optType=="C")
        return CallGamma();
    else
        return PutGamma();
}

double Option::Gamma(const vector<double> param)
{
    T=param[0];
    K=param[1];
    sig=param[2];
    r=param[3];
    S=param[4];
    b=param[5];
    return Gamma();
}

vector<double> Option::Gamma(const vector<vector<double>> param)
{
    vector<double> vecG(param.size());
    for (int i=0;i<vecG.size();i++)
    {
        vecG[i]=Gamma(param[i]);
    }
    return vecG;
}

double Option::DeltaHat(double h)
{
    double P1,P2;
    S=S+h;
    P1=Price();
    S=S-2*h;
    P2=Price();
    S=S+h;
    return((P1-P2)/(2*h));
}

double Option::GammaHat(double h)
{
    double P1,P2;
    S=S+h;
    P1=Price();
    S=S-2*h;
    P2=Price();
    S=S+h;
    return((P1+P2-2*Price())/(h*h));
}

//put-call parity relationship
double Option::CallToPut(double c) const
{
    return c+K*exp(-r*T)-S;
}
double Option::PutToCall(double p) const
{
    return p-K*exp(-r*T)+S;
}

//modifier functions
void Option::toggle()
{// Change option type (C/P, P/C)
    if (optType == "C")
        optType = "P";
    else
        optType = "C";
}
