// HardCoded.cpp
//
// C++ code to price an option, essential algorithms.
//
// We take CEV model with a choice of the elaticity parameter
// and the Euler method. We give option price and number of times
// S hits the origin.
//
// (C) Datasim Education BC 2008-2011
//

#include "OptionData.hpp" 
#include "NormalGenerator.hpp"
#include "Range.cpp"
#include <boost/tuple/tuple.hpp>
#include <boost/tuple/tuple_io.hpp>
#include <cmath>
#include <vector>
#include <iostream>

template <class T> void print(const std::vector<T>& myList)
{  // A generic print function for vectors
	
    
	std::cout << std::endl << "Size of vector is " << myList.size() << "\n[";

	// We must use a const iterator here, otherwise we get a compiler error.
    typename std::vector<T>::const_iterator i;
	for (i = myList.begin(); i != myList.end(); ++i)
	{
			std::cout << *i << ",";
	}

	std::cout << "]\n";
}

//a) Create generic functions to compute the standard deviation and standard error
template<typename Type>
boost::tuple<Type,Type> SDSE(vector<Type> C,Type r,Type T)
{
    Type sum1(0),sum2(0);
    int M=C.size();
    for (int i=0;i<M;i++)
    {
        sum1+=C[i]*C[i];
        sum2+=C[i];
    }
    Type sd=sqrt((sum1-sum2*sum2/M)/(M-1))*exp(-r*T);
    Type se=sd/sqrt(M);
    return boost::make_tuple(sd,se);
}

namespace SDEDefinition
{ // Defines drift + diffusion + data

	OptionData* data;				// The data for the option MC

	double drift(double t, double X)
	{ // Drift term
		return (data->r)*X; // r - D
	}

	double diffusion(double t, double X)
	{ // Diffusion term
		double betaCEV = 1.0;
		return data->sig * pow(X, betaCEV);
	}

	double diffusionDerivative(double t, double X)
	{ // Diffusion term, needed for the Milstein method
		double betaCEV = 1.0;
		return 0.5 * (data->sig) * (betaCEV) * pow(X, 2.0 * betaCEV - 1.0);
	}
} // End of namespace


int main()
{
	std::cout <<  "1 factor MC with explicit Euler\n";
	OptionData myOption;
	
    //using batch 1
    myOption.K = 155;
	myOption.T = 1.25;
	myOption.r = 0.03;
	myOption.sig = 0.25;
	myOption.type = 1;	// Put -1, Call +1
	double S_0 = 150;
    
    
    //using batch 2
    //myOption.K = 100;
    //myOption.T = 1;
    //myOption.r = 0.0;
    //myOption.sig = 0.2;
    //myOption.type = -1;    // Put -1, Call +1
    //double S_0 = 100;
    
	
	long N = 500;
	//std::cout << "Number of subintervals in time: ";
	//std::cin >> N;

	// Create the basic SDE (Context class)
	Range<double> range (0.0, myOption.T);
	double VOld = S_0;
	double VNew;

	std::vector<double> x = range.mesh(N);
	

	// V2 mediator stuff
	long NSim = 50000;
	//std::cout << "Number of simulations: ";
	//std::cin >> NSim;

	double k = myOption.T / double (N);
	double sqrk = sqrt(k);

	// Normal random number
	double dW;
	double price = 0.0;	// Option price

	// NormalGenerator is a base class
	NormalGenerator* myNormal = new BoostNormal();

	using namespace SDEDefinition;
	SDEDefinition::data = &myOption;

	std::vector<double> res;
    std::vector<double> vecC;
	int coun = 0; // Number of times S hits origin

	// A.
	for (long i = 1; i <= NSim; ++i)
	{ // Calculate a path at each iteration
		if ((i/10000) * 10000 == i)
		{// Give status after each 1000th iteration
				std::cout << i << std::endl;
		}

		VOld = S_0;
		for (unsigned long index = 1; index < x.size(); ++index)
		{
			// Create a random number
			dW = myNormal->getNormal();
			// The FDM (in this case explicit Euler)
			VNew = VOld  + (k * drift(x[index-1], VOld))
						+ (sqrk * diffusion(x[index-1], VOld) * dW);

			VOld = VNew;

			// Spurious values
			if (VNew <= 0.0) coun++;
		}
			
		double tmp = myOption.myPayOffFunction(VNew);
		price += (tmp)/double(NSim);
        vecC.push_back(tmp);
	}
	
	// D. Finally, discounting the average price
	price *= exp(-myOption.r * myOption.T);
    
    //calculate SD SE
    boost::tuple<double,double> result=SDSE<double>(vecC,myOption.r,myOption.T);

	// Cleanup; V2 use scoped pointer
	delete myNormal;

    std::cout << "Price, after discounting: " << price << ", " << std::endl;
    std::cout << "Number of times origin is hit: " << coun << std::endl;
    std::cout << "SD: " << result.get<0>()<<"  SE: "<<result.get<1>()<< std::endl;

	return 0;
}
