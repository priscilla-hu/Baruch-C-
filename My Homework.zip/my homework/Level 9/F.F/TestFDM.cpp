// TestEuropeanOption.cpp
//
// Test program for the exact solutions of European options and print results in Excel.
//


#ifndef max
#define max(a, b) (a > b) ? (a) : (b)
#endif

#include "FDMDirector.hpp"
#include <cmath>
#include <list>
#include <string>
#include <boost/tuple/tuple.hpp>
#include <boost/tuple/tuple_io.hpp>
#include <iostream>
#include <vector>
#include <fstream>
#include <string>
#include <cstddef>
using namespace std;


// global fucntion
vector<double> Mesh(double begin,double end,int n)
{
    vector<double> vecMesh;
    double step=(end-begin)/n;
    for (int i=0;i<n+1;i++) {vecMesh.push_back(begin+step*i);}
    return vecMesh;
}

//print vector
void print(const vector<double>& vec)
{
    for (size_t i=0;i<vec.size();++i)
    {
        cout<<vec[i]<<",";
    }
    cout<<endl;
}

//print matrix
void print(const vector<vector<double>>& matrix)
{
    cout<<endl;
    for (size_t i=0;i<matrix.size();++i)
    {
        print(matrix[i]);
    }
    cout<<endl;
}

//print Vector
void print(const Vector<double,long>&vect)
{
    cout << endl;
    for (size_t i = vect.MinIndex(); i<vect.MaxIndex(); ++i)
    {
        cout<<vect[i]<<",";
    }
    cout << endl;
}


enum OptionType
{
	Put,
	Call
};

namespace BS // Black Scholes
{
	double sig = 0.3;
	double K = 65.0;
	double T = 0.25;
	double r = 0.08;
	double D = 0.0;
	double Smax = 5.0 * K;
	enum OptionType Type = Call;

	double mySigma(double x, double t)
	{
		double sigmaS = sig * sig;
		return 0.5 * sigmaS * x * x;
	}

	double myMu(double x, double t)
	{
		return (r - D) * x;
	}

	double myB(double x, double t)
	{
		return -r;
	}

	double myF(double x, double t)
	{
		return 0.0;
	}

	double myBCL(double t)
	{
		if (Type == Call)
		{
			return 0.0;
		}
		else
		{
			return K * exp(-r * t);
		}
	}

	double myBCR(double t)
	{
		if (Type == Call)
		{
			return Smax;
		}
		else
		{
			return 0.0;
		}
	}

	double myIC(double x)
	{ // Payoff 

		if (Type == Call)
		{
			return max(x - K, 0.0);
		}
		else
		{
			return max(K - x, 0.0);
		}
	}
}

int main()
{
	// Store Batch 1 to Batch 4 data in differnet vectors.
    
    // the order of the elements in the vector: T, K, sig, r, D

    vector<double> bt1(5),bt2(5),bt3(5),bt4(5);
    bt1[0]=0.55;bt1[1]=75;bt1[2]=0.25;bt1[3]=0.06;bt1[4]=0.0;
    bt2[0]=1.0;bt2[1]=100;bt2[2]=0.2;bt2[3]=0.0;bt2[4]=0.0;
    bt3[0]=1.0;bt3[1]=10;bt3[2]=0.5;bt3[3]=0.12;bt3[4]=0.0;
    bt4[0]=30;bt4[1]=100;bt4[2]=0.3;bt4[3]=0.08;bt4[4]=0.0;
    
    
    // store the above vectors into one vector
    stringstream ss;
    string str;
    vector<vector<double>> vecBatch;
    vecBatch.push_back(bt1);
    vecBatch.push_back(bt2);
    vecBatch.push_back(bt3);
    vecBatch.push_back(bt4);

	
	using namespace ParabolicIBVP;

	// Assignment of functions
	sigma = BS::mySigma;
	mu = BS::myMu;
	b = BS::myB;
	f = BS::myF;
	BCL = BS::myBCL;
	BCR = BS::myBCR;
	IC = BS::myIC;
	
	//int J = 5.0 * BS::K;
	int J = 200;
	int N = 10000; // k = O(h^2)
	//int N = 5000;
    double Smax = 200;

	for (int i = 0; i < vecBatch.size(); i++)
	{
		cout << "Batch " << i + 1 << ", start FDM" << endl;
		ss << i + 1;
		ss >> str;
        
		ss.clear();
		std::list<std::string> labels;
		labels.push_back("Batch " + str + " Call");
		labels.push_back("Batch " + str + " Put");
		
		// Load parameter value of the batch.
		BS::T = vecBatch[i][0];
		BS::K = vecBatch[i][1];
		BS::sig = vecBatch[i][2];
		BS::r = vecBatch[i][3];
		BS::D = vecBatch[i][4];
		//BS::Smax = 5 * BS::K;
		BS::Smax = Smax;
		BS::Type = Call;

		// Calculate call option price.
		FDMDirector fdirCall(BS::Smax, BS::T, J, N);
		fdirCall.doit();
		
		// Calculate put option price.
		BS::Type = Put;
		FDMDirector fdirPut(BS::Smax, BS::T, J, N);
		fdirPut.doit();
		
        print(fdirCall.xarr);
        cout<<fdirCall.current()[60]<<endl; //S+1
        //print(fdirCall.current());
        cout<<fdirPut.current()[60]<<endl;
        //print(fdirPut.current());

		cout << "Batch " << i + 1 << ", finished" << endl;
	}
}
