//
//  AmericanOption.hpp
//  C++ Exercise
//
//  Created by 胡雨昕 on 2019/11/28.
//  Copyright © 2019 胡雨昕. All rights reserved.
//

#ifndef AmericanOption_hpp
#define AmericanOption_hpp

#include <iostream>
#include <string>
#include <vector>
using namespace std;

class AmericanOption
{
private:
    void init();
    AmericanOption copy(const AmericanOption& newOp);
    
    //kernel functions for option calculations
    double CallPrice() const;
    double PutPrice() const;
    
public:
    double K;   //strike price
    double sig; //vollatility
    double r;   //interest rate
    double S;   //strike price
    double b;   //cost of carry
    
    string optType;
    string unam;    //Name of underlying asset
    
    //constructors and destructor
    AmericanOption();
    AmericanOption(const vector<double> param); //use six parameters
    AmericanOption(const AmericanOption& opNew);
    ~AmericanOption();
    
    AmericanOption& operator=(const AmericanOption& opNew);
    
    //Option price and sensitivities
    double Price() const;
    double Price(const vector<double> param);
    vector<double> Price(const vector<vector<double>> param);
        
    //modifier functions
    void toggle();
    
};



#endif /* AmericanOption_hpp */
