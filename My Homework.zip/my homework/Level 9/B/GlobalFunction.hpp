//
//  GlobalFunction.hpp
//  C++ Exercise
//
//  Created by 胡雨昕 on 2019/11/28.
//  Copyright © 2019 胡雨昕. All rights reserved.
//

#ifndef GlobalFunction_hpp
#define GlobalFunction_hpp

#include <iostream>
#include <cmath>
#include <vector>
using namespace std;

// global fucntion
vector<double> Mesh(double begin,double end,int n)
{
    vector<double> vecMesh;
    double step=(end-begin)/n;
    for (int i=0;i<n+1;i++) {vecMesh.push_back(begin+step*i);}
    return vecMesh;
}

//print vector
void print(const vector<double>& vec)
{
    for (size_t i=0;i<vec.size();++i)
    {
        cout<<vec[i]<<",";
    }
    cout<<endl;
}

//print matrix
void print(const vector<vector<double>>& matrix)
{
    cout<<endl;
    for (size_t i=0;i<matrix.size();++i)
    {
        print(matrix[i]);
    }
    cout<<endl;
}


#endif /* GlobalFunction_hpp */
