//
//  AmericanOption.cpp
//  C++ Exercise
//
//  Created by 胡雨昕 on 2019/11/28.
//  Copyright © 2019 胡雨昕. All rights reserved.
//

#include "AmericanOption.hpp"
#include <iostream>
#include <cmath>
#include <math.h>

using namespace std;


// default initialization
void AmericanOption::init()
{
    K=110.0;   //strike price
    sig=0.2; //vollatility
    r=0.05;   //interest rate
    S=60;   //strike price
    b=r;   // Black and Scholes stock Option model (1973)
    optType="C";
}

//copy
AmericanOption AmericanOption::copy(const AmericanOption& newOp)
{
    K=newOp.K;   //strike price
    sig=newOp.sig; //vollatility
    r=newOp.r;   //interest rate
    S=newOp.S;   //strike price
    b=newOp.b;   // Black and Scholes stock option model (1973)
    optType=newOp.optType;
    return *this;
}

//kernel functions for option calculations
double AmericanOption::CallPrice() const
{
    double tmp=0.5-b/(sig*sig);
    double y1=tmp+sqrt(tmp*tmp+2*r/(sig*sig));
    
    return K/(y1-1)*pow((y1-1)*S/(y1*K),y1);
}

double AmericanOption::PutPrice() const
{
    double tmp=0.5-b/(sig*sig);
    double y2=tmp-sqrt(tmp*tmp+2*r/(sig*sig));
    
    return K/(1-y2)*pow((y2-1)*S/(y2*K),y2);
}



//constructors and destructor
AmericanOption::AmericanOption()
{
    init();
}

AmericanOption::AmericanOption(const vector<double> param)
{
    init();
    K=param[0];
    sig=param[1];
    r=param[2];
    S=param[3];
    b=param[4];
}

AmericanOption::AmericanOption(const AmericanOption& opNew)
{
    copy(opNew);
}

AmericanOption::~AmericanOption(){}

AmericanOption& AmericanOption::operator=(const AmericanOption& opNew) //assignment operator
{
    if (this==&opNew){return *this;}
    copy(opNew);
    return *this;
}

//Option price and sensitivities
double AmericanOption::Price() const
{
    if (optType == "C")
    {
        cout << "calling call\n";
        return CallPrice();
    }
    else
    {
        cout << "calling put\n";
        return PutPrice();
    }
}
double AmericanOption::Price(const vector<double> param)
{
    K=param[0];
    sig=param[1];
    r=param[2];
    S=param[3];
    b=param[4];
    return Price();
}

vector<double> AmericanOption::Price(const vector<vector<double>> param)
{
    vector<double> vecP(param.size());
    for (int i=0;i<vecP.size();i++)
    {
        vecP[i]=Price(param[i]);
    }
    return vecP;
}


//modifier functions
void AmericanOption::toggle()
{// Change option type (C/P, P/C)
    if (optType == "C")
        optType = "P";
    else
        optType = "C";
}
