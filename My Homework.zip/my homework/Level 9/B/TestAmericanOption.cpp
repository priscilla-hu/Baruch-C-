//
//  TestAmericanOption.cpp
//  C++ Exercise
//
//  Created by 胡雨昕 on 2019/11/28.
//  Copyright © 2019 胡雨昕. All rights reserved.
//

#include <iostream>
#include "GlobalFunction.hpp"
#include "AmericanOption.hpp"
#include <cmath>
#include <vector>
using namespace std;

int main()
{
    //b. test data
    
    vector<double> bt(5);
    bt[0]=100;bt[1]=0.1;bt[2]=0.1;bt[3]=110;bt[4]=0.02;
    //order: K sig r S b

    AmericanOption amop(bt);
    double cp=amop.Price();
    cout<<"call price= "<<cp<<endl;
    amop.toggle();
    double pp=amop.Price();
    cout<<"put price= "<<pp<<endl;
    
    //c. compute call and put price for a range of S
    vector<double> vecS=Mesh(10,50,40);
    vector<double> vecP(41);
    amop.optType="C";
    for (int i=0;i<41;i++)
    {
        amop.S=vecS[i];
        vecP[i]=amop.Price();
    }
    print(vecP);
    
    //d. input a matrix of parameters
    
    //create a input matrix
    vector<vector<double>> opParam(41);
    for (int i=0;i<41;i++)
    {
        opParam[i].push_back(100);   //K
        opParam[i].push_back(0.1);  //sig
        opParam[i].push_back(0.1); //r
        opParam[i].push_back(110);   //S
        opParam[i].push_back(0.02); //b
    }
    
    //volatillity
    vector<vector<double>> opParamV=opParam;
    vector<double> vecV=Mesh(0.1,1,40);
    for (int i=0;i<41;i++)
    {
        opParamV[i][1]=vecV[i]; //sig
    }
    cout<<"Input matrix: "<<endl;
    print(opParamV);
    AmericanOption amop1;
    print(amop1.Price(opParamV));
}
