//
//  main.cpp
//  test the Array class
//
//
//

#include <iostream>
#include "Point.hpp"
#include "Line.hpp"
#include "Array.hpp"
#include "Circle.hpp"
#include <sstream>


int main()
{
    Priscilla::CAD::Point pt1(2,2),pt2(3,3); // the full namespace for Point class
    
    using Priscilla::CAD::Line; //using declaration for using a single class (Line)
    Line l(pt1,pt2);
    std::cout<<l.ToString()<<std::endl;
    
    using namespace Priscilla::Containers; //using declaration for a complete namespace (Containers)
    Array arr1;
    std::cout<<arr1.Size()<<std::endl;
    
    namespace cl=Priscilla::CAD; //using the Circle class by creating a shorter alias for the YourName::CAD namespace.
    cl::Circle cl1;
    std::cout<<cl1.Radius()<<std::endl;

}
