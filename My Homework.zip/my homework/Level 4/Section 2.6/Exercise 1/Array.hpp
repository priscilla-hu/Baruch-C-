//
//  Array.hpp
//
//

#ifndef Array_hpp
#define Array_hpp

#include <iostream>
#include "Point.hpp"

namespace Priscilla
{
    namespace Containers
    {
        class Array
        {
        private:
            int size=10;
            CAD::Point* m_data;
            
        public:
            Array();
            Array(int size);
            Array(Array& a);
            ~Array();
            
            Array operator = (const Array& source); // Assignment operator.
            
            //fucntions
            int Size();
            void SetElement(int index,CAD::Point pt);
            CAD::Point GetElement(int index);
            CAD::Point& operator[](int index);
            const CAD::Point& operator [] (int index) const;
        };
    }
}




#endif /* Array_hpp */
