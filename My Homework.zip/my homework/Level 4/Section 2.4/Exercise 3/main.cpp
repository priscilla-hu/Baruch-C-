//
// constructors as conversion operator

#include <iostream>
#include <sstream>
#include "Point.hpp" //input headerfile

using namespace std;

int main()
{
    //test
    Point p(1.0, 1.0);
    if (p==1.0) cout<<"Equal!"<<endl;
    else cout<<"Not equal"<<endl;
    
    if (p==(Point)1.0) cout<<"Equal!"<<endl;
    else cout<<"Not equal"<<endl;
}
