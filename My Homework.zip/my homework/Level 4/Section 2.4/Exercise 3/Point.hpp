//
//  Point.hpp
//
// rename the DistanceOrigin() function to Distance()
// rename the SetX() andGetX() functions to just X()
//

#ifndef Point_hpp
#define Point_hpp

#include <iostream>
using namespace std;


class Point
{
private:
    double x;
    double y;
    
public:
    //constructors & destructors
    Point();
    Point(double x,double y); // Initialize with x and y value
    explicit Point(double x); //a constructor that accepts one double as an argument
    ~Point();
    
    //copy constructor
    Point(const Point& pt);
    
    
    //operators
    Point operator - () const; // Negate the coordinates.
    Point operator * (double factor) const; // Scale the coordinates.
    Point operator + (const Point& p) const; // Add coordinates.
    bool operator == (const Point& p) const; // Equally compare operator.
    Point& operator = (const Point& source); // Assignment operator.
    Point& operator *= (double factor); // Scale the coordinates & assign
    
    //accessing functions
    double X() const;
    double Y() const;
    
    //modifiers
    void X(double x_new);// const;
    void Y(double y_new);
    
    std::string ToString() const;
    
    double Distance() const;
    double Distance(const Point& p) const;
    
    
};

// the << operator
ostream& operator << (ostream& os,const Point& p);




#endif /* Point_hpp */

