//
//  Line.hpp
//  C++ Exercise
//
//  Created by 胡雨昕 on 2019/9/11.
//  Copyright © 2019 胡雨昕. All rights reserved.
//

#ifndef Line_hpp
#define Line_hpp

#include <iostream>
#include "Point.hpp"
using namespace std;

class Line
{
private:
    Point P1;
    Point P2;
public:
    Line(); //default constructor
    Line(Point& P1, Point& P2); //constructor with start and end point
    ~Line();
    
    Line(const Line& ln);
    
    Point start() const;
    Point end() const;
    
    void start(Point& P1_new);
    void end(Point& P2_new);
    
    double Length() const;
    string ToString() const;
    
    Line& operator = (const Line& source); // Assignment operator.
};
#endif /* Line_hpp */
