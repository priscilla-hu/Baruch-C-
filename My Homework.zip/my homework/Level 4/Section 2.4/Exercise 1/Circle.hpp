//
//  Circle.hpp
//  C++ Exercise
//
//  Created by 胡雨昕 on 2019/9/11.
//  Copyright © 2019 胡雨昕. All rights reserved.
//

#ifndef Circle_hpp
#define Circle_hpp

#include <iostream>
#include "Point.hpp"
using namespace std;

class Circle
{
private:
    Point CentrePt;
    double r;
    
public:
    //constructor and disructor
    Circle();
    Circle(Point& CentrePt, double r);
    ~Circle();
    
    //selector
    Point CentrePoint() const;
    double Radius() const;
    
    double Diameter() const;
    double Area() const;
    double Circumference() const;
    string ToString() const;
    
    //modifier
    void CentrePoint(Point new_CentrePt);
    void Radius(double new_r);
    
    Circle& operator = (const Circle& source);
};

#endif /* Circle_hpp */
