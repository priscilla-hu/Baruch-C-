//
//  main.cpp
//  C++ Exercise
//
// rename the DistanceOrigin() function to Distance()
// rename the SetX() andGetX() functions to just X()

#include <iostream>
#include <sstream>
#include "Point.hpp" //input headerfile
using namespace std;

int main()
{
    double x,y;
    string str_x,str_y;
    
    cout<<"enter x- and y-coordinates:";
    cin>>x>>y; //ask user for x,y
    
    Point pt1; //create a Point object
    
    pt1.X(x); //set the coordinates
    pt1.Y(y);
    
    //test the operators
    Point pt2(1,1);
    
    cout<<(-pt1).ToString()<<endl;
    cout<<(pt1*2).ToString()<<endl;
    cout<<(pt1+pt2).ToString()<<endl;
    
    stringstream stream;
    string result;
    stream << (pt1==pt2);
    stream >> result;
    cout<<result<<endl;
    
    pt1=pt2;
    cout<<pt1.ToString()<<endl;
    pt1*=2;
    cout<<pt1.ToString()<<endl;
    
    pt1=pt2*=3;
    cout<<pt1.ToString()<<endl; //关于this，为什么没用？？
    
    return 0;
}
