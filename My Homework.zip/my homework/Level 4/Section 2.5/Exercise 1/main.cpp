//
// Dynamically creating objects

#include <iostream>
#include <sstream>
#include "Point.hpp" //input headerfile
using namespace std;

int main()
{
    //create Point objects
    Point* pt1;
    pt1= new Point;
    
    Point* pt2;
    pt2= new Point(1,2);
    
    Point* pt3=new Point(*pt1);
    
    // test the distance function
    (*pt1).Distance(*pt2);
    cout<<pt1<<endl;
    cout<<pt2<<endl;
    cout<<pt3<<endl;
    
    delete pt1;
    delete pt2;
    delete pt3;
    
    //create an array of points
    int n;
    cin>>n;
    //Point p_array[n]; //check if there is a compile error.
    
    Point* pp;
    pp= new Point[n]; // cannot use other constructors than the defualt constructor
    delete [] pp;
    return 0;
    
}
