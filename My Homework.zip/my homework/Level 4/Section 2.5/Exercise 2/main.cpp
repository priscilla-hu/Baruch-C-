//
// creating array of pointers

#include <iostream>
#include <sstream>
#include "Point.hpp" //input headerfile
using namespace std;

int main()
{
    Point** pt;
    Point pt0(1,1),pt1(2,2),pt2(3,3);
    pt=new Point*[3]; // watch out in this line!!
    pt[0]=new Point(1,1);
    pt[1]=new Point(2,2);
    pt[2]=new Point(3,3);
    for (int i=0;i<3;i++)
        cout<<*(pt[i])<<endl;
    for (int i=0;i<3;i++)
        delete pt[i];
    delete [] pt;
    
}
