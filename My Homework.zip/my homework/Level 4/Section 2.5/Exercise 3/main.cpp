//
//  main.cpp
//  test the Array class
//
//
//

#include <iostream>
#include "Point.hpp"
#include "Array.hpp"
#include <sstream>
using namespace std;

int main()
{
    Point pt1(2,2),pt2(3,3);
    Array arr1(3);
    Array arr2(arr1);
    Array arr3;
    arr3=arr1;
    
    cout<<arr1.Size()<<endl;
    arr1.SetElement(2,pt1);
    cout<<arr1.GetElement(1).ToString()<<endl;
    Point a=arr1[2]; //为啥不能返回reference

}
