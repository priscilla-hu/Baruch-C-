//
//  Array.cpp

//

#include "Array.hpp"
#include <iostream>

Array::Array()
{
    m_data=new Point[size];
}
Array::Array(int s)
{
    size=s;
    m_data=new Point[size];
}
Array::Array(const Array& a)
{
    size=new int;
    size
    m_data=new Point[a.size];
    for (int i=0;i<a.size;i++)
        m_data[i]=a.m_data[i];
}
Array::~Array()
{
    delete [] m_data;
}

Array Array::operator = (const Array& a) // Assignment operator.
{
    if (&a!=this)
    { //check if the source object is not the same as the this object
        //since array is already exist when you call an assignment operator,
        //you have to delete the memory first.
        delete [] m_data;
        m_data=new Point[a.size];
        for (int i=0;i<a.size;i++)
            m_data[i]=a.m_data[i];
    }
    return *this; //注意，operator最后要有return！
}

//fucntions
int Array::Size() const
{
    return size;
}
void Array::SetElement(int index,Point pt)
{
    if (index<size)
    {
        m_data[index]=pt;
    }
}
Point Array::GetElement(int index) const
{
    if (index>size-1){
        index=0;
    }
    return m_data[index];
}
Point& Array::operator[](int index)
{
    if (index>size-1)|(index<0){
        index=0;
    }
    
    return m_data[index];
}
const Point& Array::operator [] (int index) const
{
    if (index>size-1){
        index=0;
    }
    return m_data[index];
}


