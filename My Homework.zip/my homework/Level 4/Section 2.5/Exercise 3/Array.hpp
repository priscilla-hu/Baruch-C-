//
//  Array.hpp
//
//

#ifndef Array_hpp
#define Array_hpp

#include <iostream>
#include "Point.hpp"

class Array
{
private:
    int size=10;
    Point* m_data;
    
public:
    Array();
    Array(int size);
    Array(const Array& a);
    ~Array();
    
    Array operator = (const Array& source); // Assignment operator.
    
    //fucntions
    int Size() const;
    void SetElement(int index,Point pt);
    Point GetElement(int index) const;
    Point& operator[](int index);
    const Point& operator [] (int index) const;
    
    // the reason to create two versions:
    //when you create a const object, the const type [] function will be called, but if you create a non-const object, the non-const type [] function,
    //So always add the key word "const" before the object if you don't want the object to be altered, and it will call the const type [] function whenever needed instead of non-const type [] function
    
    
};


#endif /* Array_hpp */
