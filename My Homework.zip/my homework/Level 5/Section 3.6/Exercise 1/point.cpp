//
//  Point.cpp
//
// rename the DistanceOrigin() function to Distance()
// rename the SetX() andGetX() functions to just X()
//
#include <iostream>
#include <sstream>
#include <cmath>
#include "Point.hpp"
using namespace std;
using namespace Priscilla::CAD;

Point::Point() : x(0), y(0)
{
    //cout<<"constructor is called!"<<endl;
}

Point::Point(double newx, double newy) : x(newx), y(newy)  //这一行什么意思？
{
    //cout<<"constructor is called!"<<endl;
}

Point::Point(const Point& pt)
{
    //cout<<"copy constructor is called!"<<endl;
    x=pt.x;
    y=pt.y;
}

Point::~Point()
{// Desconstructor
    //cout<<"destructor is called!"<<endl;
}


//selectors

//access the x value

double Point::X() const
{
    return x;
}

//access the y value
double Point::Y() const
{
    return y;
}

//modifiers

//set the x value
void Point::X(double x_new)
{
    x=x_new;
    return;
}

//set the y value
void Point::Y(double y_new)
{
    y=y_new;
    return;
}

//to string
string Point::ToString() const
{
    stringstream stream_x,stream_y;
    string result_x,result_y;
    
    stream_x << Point::X();
    stream_x >> result_x;
    stream_y << Point::X();
    stream_y >> result_y;
    
    return "Point("+result_x+","+result_y+")";
}

//distance
double Point::Distance() const
{
    double x_d,y_d;
    x_d=Point::X();
    y_d=Point::Y();
    return sqrt(x_d*x_d+y_d*y_d);
}

double Point::Distance(const Point& p) const
{
    double x_d,y_d;
    double x_p,y_p;
    x_d=Point::X();
    y_d=Point::Y();
    x_p=p.X(); // function GetX() should be a constant function in order to be called by a constant object.
    y_p=p.Y();
    
    return sqrt(pow(x_d-x_p,2)+pow(y_d-y_p,2));
}

//operators
Point Point::operator - () const // Negate the coordinates.
{
    Point pt;
    pt.x=-x;
    pt.y=-y;
    return pt;
}

Point Point::operator * (double factor) const // Scale the coordinates.
{
    Point pt;
    pt.x=x*factor;
    pt.y=y*factor;
    return pt; //since it's a const member function, we cannot use this.
}

Point Point::operator + (const Point& p) const // Add coordinates.
{
    Point pt;
    pt.x=x+p.X();
    pt.y=y+p.Y(); //can I use p.y instead?
    return pt;
}

bool Point::operator == (const Point& p) const // Equally compare operator.
{
    if (x==p.X() and y==p.Y())
    {
        return true;
    }
    return false;
}

Point& Point::operator = (const Point& source) // Assignment operator.
{
    x=source.X();
    y=source.Y();
    return *this;
}

Point& Point::operator *= (double factor) // Scale the coordinates & assign
{
    x=x*factor;
    y=y*factor;
    return *this;
}
