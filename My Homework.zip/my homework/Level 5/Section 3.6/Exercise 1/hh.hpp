//
//  hh.hpp
//  C++ Exercise
//
//  Created by 胡雨昕 on 2019/10/11.
//  Copyright © 2019 胡雨昕. All rights reserved.
//

#ifndef hh_hpp
#define hh_hpp

#include <stdio.h>

#endif /* hh_hpp */
