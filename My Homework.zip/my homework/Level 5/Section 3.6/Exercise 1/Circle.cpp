//
//  Circle.cpp
//  C++ Exercise
//
//  Created by 胡雨昕 on 2019/9/11.
//  Copyright © 2019 胡雨昕. All rights reserved.
//

#include "Circle.hpp"
#include "cmath"
#include "sstream"
using namespace Priscilla::CAD;

Circle::Circle()
{
    
}
Circle::Circle(Point& new_CentrePt, double new_r):CentrePt(new_CentrePt),r(new_r)
{
    
}
Circle::~Circle()
{
    
}

//selector

Point Circle::CentrePoint() const
{
    return CentrePt;
}
double Circle::Radius() const
{
    return r;
}
double Circle::Diameter() const
{
    return 2*r;
}
double Circle::Area() const
{
    return M_PI*r*r;
}
double Circle::Circumference() const
{
    return 2*M_PI*r;
}
string Circle::ToString() const
{
    stringstream stream_r;
    string result_r;
    
    stream_r << r;
    stream_r >> result_r;
    
    return "the circle has a centre point "+CentrePt.ToString()+" and a radius of "+result_r;
}
