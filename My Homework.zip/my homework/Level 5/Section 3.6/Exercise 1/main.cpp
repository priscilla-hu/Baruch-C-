//
//  main.cpp
//  test the Array class
//
//

#include <iostream>
#include "Point.hpp"
#include "Line.hpp"
#include "Array.hpp"
#include "Circle.hpp"
#include <sstream>

// In the main program, create an Array object and access an element that does not exist. Run the program. What happens?
// The exception must be caught, so place the code inside a try ... catch block that catches an int.
// In the catch handler, print an error message.

int main()
{
    try{
        using namespace Priscilla::Containers; //using declaration for a complete namespace (Containers)
        Array arr1;
        Priscilla::CAD::Point pt=arr1.GetElement(11);
        std::cout<<arr1.Size()<<std::endl;
    }
    catch(int err)
    {
        if (err==-1) cout<<"accessing an element that does not exist."<<endl;
    }
}
