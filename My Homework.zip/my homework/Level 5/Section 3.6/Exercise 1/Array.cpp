//
//  Array.cpp
// Change the Array class to throw exceptions:
//In the GetElement(), SetElement() and index operator throw -1 if the index was toosmall or too big.
//

#include "Array.hpp"
#include <iostream>
using namespace Priscilla;

Containers::Array::Array()
{
    m_data=new CAD::Point[size];
}
Containers::Array::Array(int s)
{
    size=s;
    m_data=new CAD::Point[size];
}
Containers::Array::Array(Array& a)
{
    size=a.size;
    m_data=new CAD::Point[a.size];
    for (int i=0;i<a.size;i++)
        m_data[i]=a.m_data[i];
}
Containers::Array::~Array()
{
    delete [] m_data;
}

Containers::Array Containers::Array::operator = (const Containers::Array& a) // Assignment operator.
{
    if (&a!=this)
    { //check if the source object is not the same as the this object
        //since array is already exist when you call an assignment operator,
        //you have to delete the memory first.
        delete [] m_data;
        m_data=new CAD::Point[a.size];
        for (int i=0;i<a.size;i++)
            m_data[i]=a.m_data[i];
    }
    return *this; //注意，operator最后要有return！
}

//fucntions
int Containers::Array::Size()
{
    return size;
}
void Containers::Array::SetElement(int index,CAD::Point pt)
{
    if (index>=size|index<0) throw -1;
    m_data[index]=pt;
}
CAD::Point Containers::Array::GetElement(int index)
{
    if (index>=size|index<0) throw -1;
    return m_data[index];
}
CAD::Point& Containers::Array::operator[](int index)
{
    if (index>=size|index<0) throw -1;
    return m_data[index];
}
const CAD::Point& Containers::Array::operator [] (int index) const
{
    if (index>=size|index<0) throw -1;
    return m_data[index]; //&m_data[index]为啥不行？？
}

