//
//  Array.hpp
//
//• Give the ArrayException an abstract GetMessage() function that returns a std::string.
//• Give the OutOfBoundsException class a constructor with an int as argument that
//indicates the erroneous array index and store it in a data member.
//• Override the GetMessage() function and let the implementation return a message
//string saying the given index is out of bounds.
//• In the Array class, throw now a OutOfBoundsException object instead of an integer.

//

#ifndef Array_hpp
#define Array_hpp

#include <iostream>
#include "Point.hpp"

class ArrayException
{
public:
    virtual std::string GetMessage() const =0;
};

class OutOfBoundException:public ArrayException
{
private:
    int index;
public:
    OutOfBoundException(int i);
    ~OutOfBoundException();
    std::string GetMessage() const; //declaration 与 base class 要完全一致
};

class Array
{
private:
    int size=10;
    Point* m_data;
    
public:
    Array();
    Array(int size);
    Array(const Array& a);
    ~Array();
    
    Array operator = (const Array& source); // Assignment operator.
    
    //fucntions
    int Size() const;
    void SetElement(int index,Point pt);
    Point GetElement(int index) const;
    Point& operator[](int index);
    const Point& operator [] (int index) const;
};



#endif /* Array_hpp */
