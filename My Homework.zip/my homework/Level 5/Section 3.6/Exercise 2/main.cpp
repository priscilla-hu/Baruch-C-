//
//  main.cpp
//  test the Array class
//
//You can implement both exception classes in the header file for simplicity.
//• Give the ArrayException an abstract GetMessage() function that returns a std::string.
//• Give the OutOfBoundsException class a constructor with an int as argument that
//indicates the erroneous array index and store it in a data member.
//• Override the GetMessage() function and let the implementation return a message
//string saying the given index is out of bounds.
//• In the Array class, throw now a OutOfBoundsException object instead of an integer.
//• Change the main program so that it catches the ArrayException base class and uses
//the GetMessage() function to display an error message.
//

#include <iostream>
#include "Point.hpp"
#include "Array.hpp"
#include <sstream>
using namespace std;

int main()
{
    try{
        Array arr1;
        Point pt=arr1.GetElement(11);
        cout<<arr1.Size()<<endl;
    }
    catch(OutOfBoundException err)
    {
        cout<<err.GetMessage()<<endl; //uses the GetMessage() function to display an error message.
    }
}
