//
//  Array.cpp
//
//• Give the ArrayException an abstract GetMessage() function that returns a std::string.
//• Give the OutOfBoundsException class a constructor with an int as argument that
//indicates the erroneous array index and store it in a data member.
//• Override the GetMessage() function and let the implementation return a message
//string saying the given index is out of bounds.
//• In the Array class, throw now a OutOfBoundsException object instead of an integer.
//

#include "Array.hpp"
#include <iostream>
#include <sstream>
using namespace std;

OutOfBoundException::OutOfBoundException(int i)
{
    index=i;
}
OutOfBoundException::~OutOfBoundException(){}

std::string OutOfBoundException::GetMessage() const
{
    stringstream t;
    string result_t;
    t<<index;
    t>>result_t;
    return "The given index:"+result_t+" is out of bounds";
}


Array::Array()
{
    m_data=new Point[size];
}
Array::Array(int s)
{
    size=s;
    m_data=new Point[size];
}
Array::Array(const Array& a)
{
    size=a.size;
    m_data=new Point[a.size];
    for (int i=0;i<a.size;i++)
        m_data[i]=a.m_data[i];
}
Array::~Array()
{
    delete [] m_data;
}

Array Array::operator = (const Array& a) // Assignment operator.
{
    if (&a!=this)
    { //check if the source object is not the same as the this object
        //since array is already exist when you call an assignment operator,
        //you have to delete the memory first.
        delete [] m_data;
        m_data=new Point[a.size];
        for (int i=0;i<a.size;i++)
            m_data[i]=a.m_data[i];
    }
    return *this;
}

//fucntions
int Array::Size() const
{
    return size;
}
void Array::SetElement(int index,Point pt)
{
    if (index>size-1|index<0) throw(OutOfBoundException(index)); //catch the OutOFBoundsException object
    m_data[index]=pt;
}
Point Array::GetElement(int index) const
{
    if (index>size-1|index<0) throw(OutOfBoundException(index));
    return m_data[index];
}
Point& Array::operator[](int index)
{
    if (index>size-1|index<0) throw(OutOfBoundException(index));
    
    return m_data[index];
}
const Point& Array::operator [] (int index) const
{
    if (index>size-1|index<0) throw(OutOfBoundException(index));
    return m_data[index];
}



