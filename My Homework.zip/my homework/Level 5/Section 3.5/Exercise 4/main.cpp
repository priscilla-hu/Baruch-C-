//
//  main.cpp
//
// 1. Create the Draw() function in the Shape base class and override it in the derived classes
// 2. Try to create an instance of the Shape class. Is this possible? NO
// 3. draw all the shapes using the following code:

#include <stdio.h>
#include "Line.hpp"
#include "Point.hpp"
#include "Shape.hpp"

int main()
{
    //Shape sp; //error: Variable type 'Shape' is an abstract class
    Shape* shapes[10];
    shapes[0]=new Line;
    shapes[1]=new Point;
    for (int i=2;i!=9;i++) shapes[i]=new Point;
    shapes[9]=new Line(Point(1,2.5),Point(3.4,5.2));

    for (int i=0; i!=10; i++) shapes[i]->Draw();
    for (int i=0; i!=10; i++) delete shapes[i];
}
