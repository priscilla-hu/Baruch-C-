//
//  Shape.hpp
//
// add Draw() function
//

#ifndef Shape_hpp
#define Shape_hpp

#include <iostream>
using namespace std;

class Shape
{
private:
    int id;
public:
    Shape(); //default constructor
    virtual ~Shape();
    Shape(const Shape& sp); //copy constructor
    void operator =(const Shape& sp); //assignment operator
    //string ToString() const;
    virtual string ToString() const; //returns the id as string
    int ID() const; //retrieve the id of the shape
    
    // add Draw() function
    virtual void Draw()const =0 ;
};
#include <stdio.h>

#endif /* Shape_hpp */
