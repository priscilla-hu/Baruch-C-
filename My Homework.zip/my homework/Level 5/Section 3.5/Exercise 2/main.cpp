//
//  main.cpp
//
// calling base class functionality
// call the ToString() method of base class in the ToString method() of Point and Line
//Append the shape description string to the point description string before returning.
// (in Point.cpp and Line.cpp)

//Test the application again. Is now the ID printed when printing a point or line? YES
//

#include <stdio.h>
#include "Line.hpp"
#include "Point.hpp"
#include "Shape.hpp"

int main()
{
    Shape* pt;
    pt=new Point(2,3);
    cout<<(*pt).ToString()<<endl;
    delete pt;
    
    Shape* ln;
    ln=new Line;
    cout<<(*ln).ToString()<<endl;
    delete ln;
    
}
