//
//  main.cpp
//
// 1. Add a Print() function to the Shape class.
// 2. In this function, call the ToString() function and send the result to the cout object.
// 3. In the test program, create a point and line object and call the Print() function. Does it
// print the right information even when point and line do not have the Print() function?


#include <stdio.h>
#include "Line.hpp"
#include "Point.hpp"
#include "Shape.hpp"

int main()
{
    Shape *l,*p;
    l=new Line();
    p=new Point();
    (*l).Print();
    (*p).Print();
}
