//
//  main.cpp
//  test  polymorphic ToString() function
//  answer: the ToSgtring() function of Shape is called instead of Point
//

#include <stdio.h>
#include "Line.hpp"
#include "Point.hpp"
#include "Shape.hpp"

int main()
{
    Shape* pt;
    pt=new Point(2,3);
    cout<<(*pt).ToString()<<endl;
    delete pt;
}
