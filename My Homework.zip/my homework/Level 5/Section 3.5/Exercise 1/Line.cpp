//
//  Line.cpp
//
// add constructor in the Shapebase class to the constructor.
// overwrite the assignment operator
//

#include "Line.hpp"
#include <iostream>
#include <sstream>

Line::Line(): Shape()
{
    Point pt1(0,0);Point pt2(0,0);
    P1=pt1;
    P2=pt2;
}

Line::Line(Point& new_P1, Point& new_P2): Shape()
{
    P1=new_P1;
    P2=new_P2;
}

Line::Line(const Line& ln): Shape(ln)
{
    P1=ln.P1;
    P2=ln.P2;
}

Line::~Line()
{
    
}

Point Line::start() const
{
    return P1;
}

Point Line::end() const
{
    return P2;
}

void Line::start(Point& P1_new)
{
    P1=P1_new;
}

void Line::end(Point& P2_new)
{
    P2=P2_new;
}

double Line::Length() const
{
    return P1.Distance(P2);
}

string Line::ToString() const
{
    string s=Shape::ToString();
    return s+", the Line starts with "+P1.ToString()+" and ends with "+P2.ToString();
}


ostream& operator << (ostream& os,const Line& l)
{
    os<<"start point:"<<l.P1<<","<<"end point:"<<l.P2;
    return os;
}

Line Line::operator =(const Line& ln) //assignment operator
{
    if (this==&ln) return *this;
    
    Shape::operator=(ln); //call the base class asignment
    
    P1=ln.P1;
    P2=ln.P2;
    return *this;
}

