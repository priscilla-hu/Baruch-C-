//
//  main.cpp
//  virtual destructor
//  changed the constructors in Line.cpp into colon syntax
//  proper destructors are called now

#include <stdio.h>
#include "Line.hpp"
#include "Point.hpp"
#include "Shape.hpp"

int main()
{
    Shape* shapes[3];
    shapes[0]=new Shape;
    shapes[1]=new Point;
    shapes[2]=new Line;
    for (int i=0; i!=3; i++) delete shapes[i];
    
}
