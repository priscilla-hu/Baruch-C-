//
//  Line.hpp
//
// print some text in constructors,destructor and also assignment operator
//

#ifndef Line_hpp
#define Line_hpp

#include <iostream>
#include "Point.hpp"
using namespace std;




class Line
{
private:
    Point P1;
    Point P2;
public:
    Line(); //default constructor
    Line(Point& P1, Point& P2); //constructor with start and end point
    ~Line();
    
    Line(const Line& ln);
    
    Point start() const;
    Point end() const;
    
    void start(Point& P1_new);
    void end(Point& P2_new);
    
    double Length() const;
    string ToString() const;
    
    friend ostream& operator << (ostream& os,const Line& l);
};


#endif /* Line_hpp */

