//
//  main.cpp
//
// test program:
// Before using colon syntex in Line class, both constructor and destructor are called 4 times
// After using colon syntex in Line class, both constructor and destructor are called only 2 times
//

#include <iostream>
#include <sstream>
#include "Point.hpp" //input headerfile
#include "Line.hpp"
using namespace std;

int main()
{
    Line l;
}
