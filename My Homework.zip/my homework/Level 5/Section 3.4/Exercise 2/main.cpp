//
//  main.cpp
//  
//

#include <stdio.h>
#include "Line.hpp"
#include "Point.hpp"
#include "Shape.hpp"

int main()
{
    Shape s;// Create shape.
    Point p(10, 20);// Create point.
    Point pt1(1,2);Point pt2(3, 4);
    Line l(pt1,pt2); // Create line.
    
    cout<<s.ToString()<<endl;// Print shape. ID:16807
    cout<<p.ToString()<<endl;// Print point. Point(10,10)
    cout<<l.ToString()<<endl;// Print line. the Line starts with Point(1,1) and ends with Point(3,3)
    
    cout<<"Shape ID: "<<s.ID()<<endl; // ID of the shape. Shape ID: 16807
    cout<<"Point ID: "<<p.ID()<<endl; // ID of the point. Does this work? YES. Point ID: 282475249
    cout<<"Line ID: "<<l.ID()<<endl; // ID of the line. Does this work? YES. Line ID: 1144108930
    
    Shape* sp; // Create pointer to a shape variable.
    sp=&p; // Point in a shape variable. Possible? YES
    cout<<sp->ToString()<<endl;// What is printed? ID:282475249
    
    // Create and copy Point p to new point.
    Point p2;
    p2=p;
    cout<<p2<<", "<<p2.ID()<<endl;
    // Is the ID copied if you do not call.
    // YES. The output: (10,20), 282475249
    
    // the base class assignment in point?
    // YES.
}
